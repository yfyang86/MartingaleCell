(defsystem :sb-js :class require-system)
