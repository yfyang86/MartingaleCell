# SBCL on WebAssembly — release bundle

SBCL `2.4.8-wasm.1` plus the master syncs of 2026-09 (through the
third), built from `wasm-dev` at commit `74b7662b5` on macOS arm64.
Everything here runs without a build: a Wasmtime-based host, the
runtime module, the Lisp core and its core module, and the contribs.

## What is here

| File | What |
|---|---|
| `sbcl-wasm` | the host: a Rust program embedding Wasmtime (macOS arm64; `wasm/crates/sbcl-wasm-host` in the repository builds it for Linux) |
| `sbcl.wasm` | the C runtime (heap, collector, streams, the loader), `wasm32-wasip1` |
| `sbcl.core` | the Lisp heap image after the warm load |
| `sbcl-core.wasm` | the core module: every compiled Lisp function of the core, one Wasm module |
| `sbcl-home/contrib/` | the pure-Lisp contribs for `(require :asdf)`, `:sb-md5`, ... |
| `run-sbcl.sh` | the launcher |
| `web/` | the browser host (see below) |

`sbcl.core` and `sbcl-core.wasm` must stay next to each other; the
runtime derives the module's name from the core's.

## Running

```
./run-sbcl.sh --noinform                     # the REPL
./run-sbcl.sh --noinform --eval '(print (+ 1 2))' --quit
./run-sbcl.sh --noinform --script hello.lisp
```

Standard input and output are the terminal's; errors enter the
debugger (`--disable-debugger` or `--non-interactive` to change
that); `--dynamic-space-size 512MB` is the default heap.

The current directory is visible to the Lisp side (WASI preopen):
`(load "foo.lisp")` loads a file beside you; `compile` and
`compile-file` work; `save-lisp-and-die` writes a new core plus its
own core module (keep them together, run them the same way).

In the browser: `node web/serve.mjs` (from this directory), then
`http://127.0.0.1:8625/`: a REPL page running the same core under
V8. Chromium and Firefox; the first load fetches about 124 MB.

## What works, what does not

Works: the whole language (the ANSI suite has 0 unexpected failures),
the compiler at run time, PCL, the condition system and the
debugger's REPL, timers and deadlines, ASDF and the pure-Lisp
contribs, `save-lisp-and-die`, both hosts.

Does not: threads, sockets, foreign libraries and callbacks, stack
(`dynamic-extent`) allocation, the debugger's backtrace and stepping,
`run-program` in the browser host. Fixnums are 30 bits. The complete
list and the caveats: `SBCL-Handoff.md` section 5 in the repository.

## Sizes and startup

About 1 s to the REPL (Wasmtime caches the core module after the
first run — `~/Library/Caches/BytecodeAlliance.wasmtime` on macOS,
`~/.cache/wasmtime` on Linux; the first run takes ~25 s).
`sbcl.core` ~79 MB, `sbcl-core.wasm` ~44 MB, `sbcl.wasm` 1.4 MB.

## Where the source and the docs are

Repository branch `wasm-dev` (`https://github.com/yfyang86/sbcl`):
`WASM-Manual.md` (build, run, debug), `SBCL-Handoff.md` (embedding),
`WASM-NEWS.md` (the change log), `doc/wasm-port/` (the design and the
sprint records under `Sprints/`).
