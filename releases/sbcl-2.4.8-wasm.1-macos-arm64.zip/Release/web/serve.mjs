// The browser host for the release bundle: the same page and worker as
// the repository's wasm/web, serving the runtime, core and core module
// from this directory instead of the build tree.
//   node serve.mjs [port]      (default 8625; SBCL_WASM_PORT)
import { createServer } from "node:http";
import { readFile } from "node:fs/promises";
import { extname, join } from "node:path";
import { fileURLToPath } from "node:url";

const here = fileURLToPath(new URL(".", import.meta.url));
const root = join(here, "..");
const port = Number(process.env.SBCL_WASM_PORT ?? process.argv[2] ?? 8625);

const types = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".wasm": "application/wasm",
  ".core": "application/octet-stream",
  ".lisp": "text/plain; charset=utf-8",
};

const urls = {
  "/": join(here, "index.html"),
  "/repl.js": join(here, "repl.js"),
  "/repl.css": join(here, "repl.css"),
  "/worker.js": join(here, "worker.js"),
  "/ring.js": join(here, "ring.js"),
  "/sbcl-host.js": join(here, "sbcl-host.js"),
  "/wasi.js": join(here, "wasi.js"),
  "/sbcl.wasm": join(root, "sbcl.wasm"),
  "/sbcl.core": join(root, "sbcl.core"),
  "/sbcl-core.wasm": join(root, "sbcl-core.wasm"),
};

const server = createServer(async (req, res) => {
  const path = new URL(req.url, "http://localhost").pathname;
  try {
    const file = urls[path];
    if (!file) throw Object.assign(new Error("not found"), { code: "ENOENT" });
    const bytes = await readFile(file);
    res.writeHead(200, {
      "content-type": types[extname(file)] ?? "application/octet-stream",
      // the worker's stdin is a SharedArrayBuffer ring (worker.js):
      // the page must be crossOriginIsolated for it
      "cross-origin-opener-policy": "same-origin",
      "cross-origin-embedder-policy": "require-corp",
      "cache-control": "no-store",
    });
    res.end(bytes);
  } catch {
    res.writeHead(404, { "content-type": "text/plain" });
    res.end(`not found: ${path}\n`);
  }
});

server.listen(port, () => {
  console.log(`sbcl-wasm web host on http://127.0.0.1:${port}/ (Ctrl-C to stop)`);
});
