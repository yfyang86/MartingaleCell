#!/bin/sh
# Run the SBCL WebAssembly port from this directory:
#   ./run-sbcl.sh [sbcl-options...]
# The core and the core module must sit next to each other (they do);
# SBCL_HOME points the contribs (REQUIRE :ASDF and the rest) out.
# The host binary, sbcl-wasm, is macOS arm64 — on Linux build it from
# the repository (wasm/crates/sbcl-wasm-host) and drop it in here.
here=$(cd "$(dirname "$0")" && pwd)
export SBCL_HOME="$here/sbcl-home"
exec "$here/sbcl-wasm" "$here/sbcl.wasm" --core "$here/sbcl.core" "$@"
