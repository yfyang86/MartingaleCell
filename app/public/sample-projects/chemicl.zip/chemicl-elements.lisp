
(in-package :chemicl)

(defclass element ()
  (;; modeling elements after the entries in data/elementdata.xml

   ;; from XML attributes
   (atomic-number :initarg :atomic-number :accessor atomic-number)
   (id :initarg :id :accessor id)
   (name :initarg :name :accessor name)
   (group :initarg :group :accessor group)
   (period :initarg :period :accessor period)

   ;; from XML elements
   (radii :initarg :radii :accessor radii :initform nil)
   (max-bond-order :initarg :max-bond-order :accessor max-bond-order)
   (mass :initarg :mass :accessor mass)
   (electronegativity :initarg :electronegativity :accessor electronegativity)

   (isotopes :initarg :isotopes :accessor isotopes :initform nil))
  (:documentation "A class for representing elements of the periodic table."))

(defclass isotope ()
  ((number :initarg :number :accessor isotope-number)
   (exact-mass :initarg :exact-mass :accessor isotope-exact-mass)
   (relative-abundance :initarg :relative-abundance
                       :accessor isotope-relative-abundance)))


(defgeneric print-element-data (object stream)
  (:method ((object element) stream)
    (format stream
            "~S ~S ~S ~S"
            (atomic-number object)
            (id object)
            (name object)
            (mass object))))

(defmethod print-object ((object element) stream)
  (print-unreadable-object (object stream :type t :identity t)
    (print-element-data object stream)))

(defvar *elements*)
(defvar *element-hash* (make-hash-table :test 'equalp))

(defun get-element (element-identifier)
  "Returns the element indicated by element-identifier. If
element-identifier is a number, the element whose atomic number is
element-identifier returned. If element-identifier is a string or a
symbol, the element whose two-letter elemental symbol matches
element-identifier is returned. Note that the string and symbol lookup
is case-insensitive, so :fe can be used to refer to the element Iron."
  (etypecase element-identifier
    (number (aref *elements* element-identifier))
    (string (gethash element-identifier *element-hash*))
    (symbol (gethash (symbol-name element-identifier) *element-hash*))))

(defun get-isotope (element-identifier mass-number)
  "Returns the isotope of the element specified by element-identifier
whose mass number (the number of protons and neutrons) is
mass-number."
  (typecase element-identifier
    (element
     (find mass-number (isotopes element-identifier)
           :key #'isotope-number))
    (t
     (find mass-number (isotopes (get-element element-identifier))
           :key #'isotope-number))))

;;; Port note: the original reads data/elementdata.xml and isotopes.xml via
;;; cxml/cxml-stp/xpath. Those XML files were converted once into
;;; elements-data.lisp (see PORT-NOTES.md), which we load here — no XML
;;; dependencies, same data.
(defun read-element-data ()
  (let ((element-list
          (loop for (atomic-number id name group period mass
                                    electronegativity max-bond-order)
                  in *element-data*
                collect (make-instance 'element
                                       :atomic-number atomic-number
                                       :id id :name name
                                       :group group :period period
                                       :mass mass
                                       :electronegativity electronegativity
                                       :max-bond-order max-bond-order))))
    (let ((max-element (apply #'max (map 'list #'atomic-number element-list))))
      (let ((array (make-array (1+ max-element) :adjustable nil)))
        (loop for l in element-list
              do (setf (aref array (atomic-number l)) l
                       (gethash (id l) *element-hash*) l))
        (setf *elements* array)))))

(defun read-isotope-data ()
  (loop for (id . isotopes) in *isotope-data*
        do (setf (isotopes (get-element id))
                 (sort (loop for (number exact-mass relative-abundance) in isotopes
                             collect (make-instance 'isotope
                                                    :number number
                                                    :exact-mass exact-mass
                                                    :relative-abundance relative-abundance))
                       #'> :key #'isotope-relative-abundance))))

(defvar *element-data*)
(defvar *isotope-data*)
(read-element-data)
(read-isotope-data)

(defparameter *element-normal-valences*
  (let ((hash (make-hash-table :test 'eq))
        (valence-list '(("B" 3)
                        ("C" 4)
                        ("N" 3 5)
                        ("O" 2)
                        ("P" 3 5)
                        ("S" 2 4 6)
                        ("F" 1)
                        ("Cl" 1)
                        ("Br" 1)
                        ("I" 1))))
    (map nil (lambda (x)
               (destructuring-bind (symbol &rest valences)
                   x
                 (let ((element (get-element symbol)))
                   (setf (gethash element hash) valences))))
         valence-list)
    hash))

(defgeneric get-normal-valence (element)
  (:method ((element element))
    (gethash element *element-normal-valences*))
  (:method ((string string))
    (get-normal-valence (get-element string)))
  (:documentation "Returns the normal valences for the specified
  element, assuming it is in the following list, otherwise NIL. The
  supported elements and their valences are: B: 3; C: 4; N: 3, 5; O:
  2; P: 3, 5; S: 2, 4, 6; F: 1, Cl: 1, Br: 1, I 1."))

