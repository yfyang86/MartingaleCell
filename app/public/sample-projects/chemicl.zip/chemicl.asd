;;; chemicl.asd — MartingaleCell port of Cyrus Harmon's chemicl (BSD).
;;; Ported for the browser runtimes: cxml/cxml-stp/xpath replaced by a
;;; generated elements-data.lisp; epigraph vendored (with a two-function
;;; alexandria shim); SMILES parsing is NOT ported (it needs
;;; parser-combinators + fset — see PORT-NOTES.md).
(asdf:defsystem #:chemicl
  :name "chemicl"
  :author "Cyrus Harmon <ch-lisp@bobobeach.com>"
  :version "0.0.2"
  :licence "BSD"
  :description "A library for representing chemical structures (MartingaleCell browser port)"
  :depends-on ()
  :serial t
  :components
  ((:file "epigraph-package")
   (:file "epigraph-utilities")
   (:file "epigraph")
   (:file "simple-edge-list-graph")
   (:file "chemicl-package")
   (:file "elements-data")
   (:file "chemicl-elements")
   (:file "chemicl-util")
   (:file "chemicl")
   (:file "chemicl-rings")
   (:file "chemicl-primes")
   (:file "chemicl-canonicalize")
   (:file "chemicl-smiles")
   (:file "chemicl-svg")))
