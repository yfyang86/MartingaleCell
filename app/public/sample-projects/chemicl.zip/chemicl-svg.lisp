;;; file: chemicl-svg.lisp
;;;
;;; 2-D depiction of chemicl molecules as SVG, for
;;;   (chemicl:show-smiles "CCO")            ; parse + draw + emit marker
;;;   (chemicl:show-molecule *caffeine*)     ; draw an existing molecule
;;;   (chemicl:molecule-svg mol)             ; just the SVG string
;;;
;;; Layout is force-directed (springs on bonds, repulsion between all
;;; atom pairs), seeded on a circle — good enough for notebook-sized
;;; molecules and engine-only: no JS, no gnuplot. The SVG travels to the
;;; page through the same ;;PLOT64 capture channel gnuplot plots use
;;; (the app recognizes a raw <svg> payload and renders it with the usual
;;; plot chrome, downloads included).
;;;
;;; Copyright (c) 2008-2014 Cyrus Harmon — molecule API (BSD, see
;;; COPYRIGHT-chemicl). This file: BSD, same terms.

(in-package #:chemicl)

;;; --------------------------------------------------------------------
;;; 2-D layout — depiction style (ring templates + zig-zag chains)

(defparameter *mol-bond-length* 42.0
  "Preferred bond length in SVG units.")

(defparameter *mol-repulsion* 2400.0
  "Strength of the all-pairs repulsion in the refinement pass.")

(defun %heavy-edges (mol)
  (remove-if (lambda (b) (or (string= (%smiles-sym (slot-value b 'epigraph:node1)) "H")
                             (string= (%smiles-sym (slot-value b 'epigraph:node2)) "H")))
             (graph:edges mol)))

(defun %neighbors-map (mol atoms)
  (let ((nb (make-hash-table :test 'eq)))
    (dolist (a atoms) (setf (gethash a nb) nil))
    (dolist (b (%heavy-edges mol))
      (let ((a1 (slot-value b 'epigraph:node1))
            (a2 (slot-value b 'epigraph:node2)))
        (push a2 (gethash a1 nb))
        (push a1 (gethash a2 nb))))
    (maphash (lambda (k v) (setf (gethash k nb) (nreverse v))) nb)
    nb))

(defun %heavy-atoms (mol)
  (remove-if (lambda (a) (string= (%smiles-sym a) "H"))
             (graph:map-nodes->list #'identity mol)))

(defun %cycles (mol atoms)
  "Smallest cycles through each non-tree edge (a good SSSR approximation
for depiction): DFS spanning forest, then each heavy non-tree edge closes
the cycle along its tree paths. Cycles come out in traversal order."
  (let ((parent (make-hash-table :test 'eq))
        (tree-edge (make-hash-table :test 'eq))
        (visited (make-hash-table :test 'eq))
        (nb (%neighbors-map mol atoms))
        (cycles '())
        (seen (make-hash-table :test 'equal)))
    (labels ((ancestors (a)
               (loop for x = a then (gethash x parent)
                     while x collect x))
             (dfs (a p)
               (setf (gethash a visited) t)
               (when p (setf (gethash a parent) p))
               (dolist (n (gethash a nb))
                 (cond ((not (gethash n visited))
                        (setf (gethash (cons a n) tree-edge) t
                              (gethash (cons n a) tree-edge) t)
                        (dfs n a))
                       ((and (not (eq n p))
                             (not (gethash (cons a n) tree-edge)))
                        ;; non-tree edge a-n: cycle = a..root ∩ reversed n..root
                        (let* ((pa (ancestors a))
                               (pn (ancestors n))
                               (common (loop for x in pa when (member x pn) collect x))
                               (root (first common))
                               (path-a (ldiff pa (member root pa)))
                               (path-n (ldiff pn (member root pn))))
                          (let ((cyc (append path-a (list root) (reverse path-n))))
                            (let ((key (sort (mapcar #'atom-name cyc) #'string<)))
                              (unless (gethash key seen)
                                (setf (gethash key seen) t)
                                (push cyc cycles))))))))))
      (dolist (a atoms) (unless (gethash a visited) (dfs a nil))))
    ;; a fundamental cycle of a fused system can be its outer envelope
    ;; (e.g. a 9-ring around saccharin's 5+6). Any chord (a bond joining
    ;; two non-adjacent cycle atoms) splits such a cycle into two smaller
    ;; real rings — repair until no cycle has a chord.
    (labels ((chord-split (cyc)
               (let* ((n (length cyc)))
                 (loop for i below n
                       do (loop for j from (+ i 2) below n
                                unless (and (= i 0) (= j (1- n)))
                                do (let ((ai (nth i cyc)) (aj (nth j cyc)))
                                     (when (and (gethash ai nb)
                                                (find aj (gethash ai nb) :test #'eq))
                                       ;; vertex lists; closure is implicit
                                       (let ((c1 (subseq cyc i (1+ j)))
                                             (c2 (append (subseq cyc j) (subseq cyc 0 (1+ i)))))
                                         (return-from chord-split
                                           (append (chord-split c1) (chord-split c2)))))))
                       finally (return (list cyc)))))
             (canonical (cyc) (sort (mapcar #'atom-name cyc) #'string<)))
      (let ((repaired '())
            (rseen (make-hash-table :test 'equal)))
        (dolist (c cycles)
          (dolist (c2 (chord-split c))
            (let ((key (canonical c2)))
              (unless (gethash key rseen)
                (setf (gethash key rseen) t)
                (push c2 repaired)))))
        (setf cycles repaired)))
    (sort cycles #'< :key #'length)))

(defun %v+ (p q) (cons (+ (car p) (car q)) (+ (cdr p) (cdr q))))
(defun %v- (p q) (cons (- (car p) (car q)) (- (cdr p) (cdr q))))
(defun %v* (p k) (cons (* (car p) k) (* (cdr p) k)))
(defun %dot (a b) (+ (* (car a) (car b)) (* (cdr a) (cdr b))))

(defun %vlen (p) (sqrt (+ (* (car p) (car p)) (* (cdr p) (cdr p)))))
(defun %unit (p)
  (let ((l (max 1e-9 (%vlen p)))) (cons (/ (car p) l) (/ (cdr p) l))))
(defun %rot (p ang)
  (cons (- (* (car p) (cos ang)) (* (cdr p) (sin ang)))
        (+ (* (car p) (sin ang)) (* (cdr p) (cos ang)))))

(defun %place-cycle-fresh (cycle pos)
  "Regular polygon at the origin, first edge horizontal."
  (let* ((n (length cycle))
         (R (/ *mol-bond-length* (* 2 (sin (/ pi n))))))
    (loop for a in cycle
          for k from 0
          for ang = (+ (/ pi 2) (* 2 pi (- k 0.5) (/ n)))
          do (setf (gethash a pos) (cons (* R (cos ang)) (* R (sin ang)))))))

(defun %place-cycle-fused (cycle pos placed-centroid)
  "Place the remaining atoms of CYCLE as a regular polygon when two of
its adjacent atoms are already placed (the shared edge of a fused ring);
pick the center on the far side from the placed mass."
  (let* ((n (length cycle))
         (R (/ *mol-bond-length* (* 2 (sin (/ pi n))))))
    ;; find the shared edge: two consecutive placed atoms in cycle order
    (loop for rest on (append cycle (list (first cycle)))
          when (and (gethash (first rest) pos) (gethash (second rest) pos))
            do (let* ((a1 (first rest)) (a2 (second rest))
                      (p1 (gethash a1 pos)) (p2 (gethash a2 pos))
                      (mid (%v* (%v+ p1 p2) 0.5))
                      (d (%vlen (%v- p2 p1)))
                      (h (sqrt (max 0.01 (- (* R R) (* d d 0.25)))))
                      (perp (let ((u (%unit (%v- p2 p1))))
                              (cons (- (cdr u)) (car u))))
                      (c1 (%v+ mid (%v* perp h)))
                      (c2 (%v+ mid (%v* perp (- h))))
                      (c (if (< (%vlen (%v- c1 (or placed-centroid '(0 . 0))))
                                (%vlen (%v- c2 (or placed-centroid '(0 . 0)))))
                             c2 c1)))
                 ;; walk the rest of the ring around the center, stepping
                 ;; the same angular direction as p1→p2
                 (let* ((u1 (atan (- (cdr p1) (cdr c)) (- (car p1) (car c))))
                        (u2 (atan (- (cdr p2) (cdr c)) (- (car p2) (car c))))
                        (step (let ((dd (- u2 u1)))
                                (if (> dd (- pi)) dd (+ dd (* 2 pi)))))
                        ;; angular direction must match cycle order a1→a2→a3…
                        (step (if (> (abs step) 1e-6) step
                                  (if (> u2 u1) (* 2 pi (- n) -1) 1.0)))
                        (idx (position a1 cycle)))
                   (loop for k from 2 below n
                         for a = (nth (mod (+ idx k) n) cycle)
                         for ang = (+ u2 (* step (- k 1)))
                         do (setf (gethash a pos)
                                  (%v+ c (cons (* R (cos ang)) (* R (sin ang))))))))
          and return t)))

(defun %placed-centroid (pos)
  (let ((x 0.0) (y 0.0) (n 0))
    (maphash (lambda (a p)
               (declare (ignore a))
               (incf x (car p)) (incf y (cdr p)) (incf n))
             pos)
    (if (zerop n) nil (cons (/ x n) (/ y n)))))


(defun %place-cycle-linked (cycle pos nb)
  "A ring attached to the placed part by a single bond (linked systems
like nicotine): place it as a regular polygon whose first vertex is
the ring atom on that bond, growing away from the placed centroid."
  (loop for r in cycle
        for p = (find-if (lambda (x)
                           (and (gethash x pos) (not (member x cycle :test #'eq))))
                         (gethash r nb))
        when (and p (gethash p pos))
          do (let* ((n (length cycle))
                    (pc (%placed-centroid pos))
                    (dir (if (> (%vlen (%v- (gethash p pos) pc)) 1.0)
                             (%unit (%v- (gethash p pos) pc))
                             (cons 1.0 0.0)))
                    (rpos (%v+ (gethash p pos) (%v* dir *mol-bond-length*)))
                    (rc (/ *mol-bond-length* (* 2 (sin (/ pi n)))))
                    (center (%v+ rpos (%v* dir rc)))
                    (base (%ang (%v- rpos center))))
               (setf (gethash r pos) rpos)
               (loop for k from 1 below n
                     for idx = (position r cycle :test #'eq)
                     for a2 = (nth (mod (+ idx k) n) cycle)
                     for ang = (+ base (* k (/ (* 2 pi) n)))
                     do (setf (gethash a2 pos)
                              (%v+ center (%v* (cons (cos ang) (sin ang)) rc))))
               (return t))
        finally (return nil)))

(defun %place-cycle-spiro (cycle pos nb &optional (dir-in nil))
  "A ring sharing exactly ONE atom with the placed part (spiro junction,
  e.g. cephalostatin's spiro ketals): place it as a regular polygon with
  the shared atom as a vertex, growing away from the placed mass."
  (loop for r in cycle
        for placed-nb = (find-if (lambda (x)
                                   (and (gethash x pos)
                                        (not (member x cycle :test #'eq))))
                                 (gethash r nb))
        when (and placed-nb (gethash r pos))
          do (let* ((n (length cycle))
                    (pc (%placed-centroid pos))
                    (home (or dir-in
                              (if (> (%vlen (%v- (gethash r pos) pc)) 1.0)
                                  (%unit (%v- (gethash r pos) pc))
                                  (cons 1.0 0.0))))
                    (rc (/ *mol-bond-length* (* 2 (sin (/ pi n)))))
                    (idx (position r cycle :test #'eq)))
               ;; try the home direction and rotations around it; keep
               ;; the polygon whose vertices keep the most clearance
               (let ((best-dir nil) (best-c -1e9))
                 (dolist (da (list 0.0 0.5 -0.5 1.0 -1.0 1.6 -1.6 2.2 -2.2 2.8 -2.8))
                   (let* ((dir (%rot home da))
                          (center (%v+ (gethash r pos) (%v* dir rc)))
                          (base (%ang (%v- (gethash r pos) center)))
                          (vs (loop for k from 1 below n
                                    for ang = (+ base (* k (/ (* 2 pi) n)))
                                    collect (%v+ center
                                                 (%v* (cons (cos ang) (sin ang)) rc))))
                          (clr (let ((m 1e9))
                                 (dolist (v vs)
                                   (maphash (lambda (b q)
                                              (declare (ignore b))
                                              (setf m (min m (%vlen (%v- v q)))))
                                            pos))
                                 m)))
                     (when (> clr best-c) (setf best-c clr best-dir dir))))
                 (let* ((dir best-dir)
                        (center (%v+ (gethash r pos) (%v* dir rc)))
                        (base (%ang (%v- (gethash r pos) center))))
                   (loop for k from 1 below n
                         for a2 = (nth (mod (+ idx k) n) cycle)
                         for ang = (+ base (* k (/ (* 2 pi) n)))
                         do (setf (gethash a2 pos)
                                  (%v+ center (%v* (cons (cos ang) (sin ang)) rc))))))
               (return t))
        finally (return nil)))

(defun %relax (mol pos atoms &key (iterations 160) (anchors nil))
  "Gentle force-directed refinement starting from the template
positions: bond springs keep the ring geometry, all-pairs repulsion
resolves collisions that chains and fused substituents can produce."
  (let ((bonds (%heavy-edges mol))
        (disp (make-hash-table :test 'eq)))
    (loop repeat iterations
          do
          (dolist (a atoms) (setf (gethash a disp) (cons 0.0 0.0)))
          (loop for (a . rest) on atoms
                do (dolist (b rest)
                     (let* ((pa (gethash a pos)) (pb (gethash b pos))
                            (dx (- (car pa) (car pb))) (dy (- (cdr pa) (cdr pb)))
                            (d (max 1.0 (sqrt (+ (* dx dx) (* dy dy)))))
                            (f (/ *mol-repulsion* (* d d))))
                       (incf (car (gethash a disp)) (* f (/ dx d)))
                       (incf (cdr (gethash a disp)) (* f (/ dy d)))
                       (incf (car (gethash b disp)) (- (* f (/ dx d))))
                       (incf (cdr (gethash b disp)) (- (* f (/ dy d)))))))
          (dolist (b bonds)
            (let* ((a1 (slot-value b 'epigraph:node1))
                   (a2 (slot-value b 'epigraph:node2))
                   (p1 (gethash a1 pos)) (p2 (gethash a2 pos))
                   (dx (- (car p1) (car p2))) (dy (- (cdr p1) (cdr p2)))
                   (d (max 1.0 (sqrt (+ (* dx dx) (* dy dy)))))
                   (want (if (= (or (slot-value b 'order) 1) 1.5)
                             (* 0.92 *mol-bond-length*) *mol-bond-length*))
                   (f (- (- d want) (* 0.5 (- d want)))))
              (incf (car (gethash a1 disp)) (* f (/ dx d)))
              (incf (cdr (gethash a1 disp)) (* f (/ dy d)))
              (incf (car (gethash a2 disp)) (- (* f (/ dx d))))
              (incf (cdr (gethash a2 disp)) (- (* f (/ dy d)))))))
          (dolist (a atoms)
            (let* ((d (gethash a disp))
                   (mag (max 1.0 (sqrt (+ (expt (car d) 2) (expt (cdr d) 2)))))
                   (lim (min mag 5.0)))
              (incf (car (gethash a pos)) (* (/ (car d) mag) lim))
              (incf (cdr (gethash a pos)) (* (/ (cdr d) mag) lim))))))

(defun %ang (v) (atan (cdr v) (car v)))

(defun %dist-to-seg (p a b)
  "Distance from point P to segment AB."
  (let* ((ab (%v- b a)) (ap (%v- p a))
         (L2 (max 1e-9 (%dot ab ab)))
         (t0 (max 0.0 (min 1.0 (/ (%dot ap ab) L2)))))
    (%vlen (%v- p (%v+ a (%v* ab t0))))))

(defun %overlap-score (atoms pos nb &optional (exclude-parents nil))
  "Lower is better: penalizes atom pairs and atom/bond contacts that are
too close for a readable depiction. Non-adjacent pairs only."
  (declare (ignore exclude-parents))
  (let ((score 0.0)
        (L *mol-bond-length*)
        (lst atoms))
    (loop for (a . rest) on lst
          for pa = (gethash a pos)
          when pa
            do (dolist (b rest)
                 (let ((pb (gethash b pos)))
                   (when pb
                     (let ((d (%vlen (%v- pb pa))))
                       ;; bonded atoms sit at ~L; closer than 0.85L or
                       ;; non-bonded closer than 1.4L is a clash
                       (let ((bonded (find b (gethash a nb) :test #'eq)))
                         (cond (bonded
                                (when (< d (* 0.85 L))
                                  (incf score (expt (- (* 0.85 L) d) 2))))
                               ((< d (* 1.35 L))
                                (incf score (expt (- (* 1.35 L) d) 2)))))))))
    ;; atom-vs-bond: an atom sitting on a bond line it is not part of
    (loop for (a . rest) on lst
          for pa = (gethash a pos)
          when pa
            do (dolist (b rest)
                 (let ((pb (gethash b pos)))
                   (when pb
                     (unless (find b (gethash a nb) :test #'eq)
                       (dolist (c (gethash b nb))
                         (let ((pc (gethash c pos)))
                           (when (and pc (not (eq c a))
                                      (not (find c (gethash a nb) :test #'eq)))
                             (let ((d (%dist-to-seg pa pb pc)))
                               (when (< d (* 0.5 L))
                                 (incf score (expt (- (* 0.5 L) d) 2)))))))))))))
    score))

(defun %ideal-directions (a placed-dirs free-count)
  "Directions for FREE-COUNT new substituents of atom A given the angles
(in radians) of already-placed bonds. Standard depiction geometry: the
total degree is spread as evenly as possible around the atom (2 -> 180,
3 -> 120, 4 -> 90), rotated so existing bonds keep their angles."
  (let* ((total (+ (length placed-dirs) free-count))
         ;; tetrahedral-ish centers (S(=O)2, NH3+...) draw better with
         ;; ~109-degree spacing than 90
         (step (cond ((<= total 1) (* 2 pi))
                     ((= total 4) 1.9)
                     (t (/ (* 2 pi) total))))
         ;; bisector of the largest gap between placed directions
         (gaps (if (null placed-dirs)
                   (list (cons 0.0 (* 2 pi)))
                   (sort (loop for (d1 . rest) on (append (sort placed-dirs #'<)
                                                          (list (+ (first (sort placed-dirs #'<)) (* 2 pi))))
                               for d2 = (or (first rest) (+ (first (sort placed-dirs #'<)) (* 2 pi)))
                               collect (cons d1 (- d2 d1)))
                         #'> :key #'cdr)))
         (anchor (+ (caar gaps) (* 0.5 (cdar gaps)))))
    ;; place the free directions centered on the anchor, step apart
    (loop for k from 0 below free-count
          collect (- anchor (* step (- (/ (1- free-count) 2.0) k))))))

(defun %place-chains (mol atoms nb cycles pos)
  "Place all non-ring atoms with standardized depiction geometry: bond
angles of 180/120/90 by degree, chains zig-zag (alternating +/- 60
degree turns, so the angle at each chain middle is 120 degrees), and
substituents on rings point radially outward. Each new atom keeps a
parent pointer for the later flip pass."
  (declare (ignore mol))
  (let* ((ring-atoms (make-hash-table :test 'eq))
         (parents (make-hash-table :test 'eq))
         ;; cycles that no template has placed yet; when the BFS first
         ;; reaches one of their atoms, the whole ring is placed as a
         ;; regular polygon (bridged rings like thiamine's pyrimidine)
         (open-cycles (remove-if (lambda (c) (some (lambda (a) (gethash a pos)) c)) cycles))
         (atom-cycle (make-hash-table :test 'eq))
         (cent (make-hash-table :test 'eq))
         (queued (make-hash-table :test 'eq))
         (turn-sign (make-hash-table :test 'eq))
         (queue nil))
    ;; ring membership + centroid of one containing ring
    (dolist (cyc cycles)
      ;; only fully-placed rings act as templates; leftovers (rings the
      ;; placer could not attach) are laid out as chains instead
      (when (every (lambda (a) (gethash a pos)) cyc)
        (let ((cx (/ (reduce #'+ (mapcar (lambda (a) (car (gethash a pos))) cyc))
                     (length cyc)))
              (cy (/ (reduce #'+ (mapcar (lambda (a) (cdr (gethash a pos))) cyc))
                     (length cyc))))
          (dolist (a cyc)
            (setf (gethash a ring-atoms) t
                  (gethash a cent) (cons cx cy))))))
    (dolist (cyc open-cycles)
      (dolist (a cyc) (setf (gethash a atom-cycle) cyc)))
    ;; frontier: placed atoms, ring atoms first (they anchor geometry)
    (setf queue (sort (copy-list (remove-if-not (lambda (a) (gethash a pos)) atoms))
                      #'> :key (lambda (a) (if (gethash a ring-atoms) 1 0))))
    (dolist (a queue) (setf (gethash a queued) t))
    (flet ((clearance (p parent)
             (let ((best 1e9))
               (maphash (lambda (b q)
                          (unless (eq b parent)
                            (setf best (min best (%vlen (%v- p q))))))
                        pos)
               best)))
      (loop while queue
            for a = (pop queue)
            for free = (remove-if (lambda (n) (or (gethash n pos)
                                                  (gethash n queued)))
                                  (gethash a nb))
            when free
              do (let* ((placed-nbs (remove-if-not (lambda (n) (gethash n pos))
                                                    (gethash a nb)))
                        (placed-dirs (mapcar (lambda (n) (%ang (%v- (gethash n pos)
                                                                   (gethash a pos))))
                                             placed-nbs))
                        (cands0 (%ideal-directions a placed-dirs (length free)))
                        ;; mirrored orientation of the candidate set;
                        ;; clearance decides which side looks better
                        (mirror (when placed-dirs
                                  (/ (reduce #'+ placed-dirs) (length placed-dirs))))
                        (cands (append cands0
                                       (when mirror
                                         (mapcar (lambda (x) (- (* 2 mirror) x))
                                                 cands0))
                                       ;; small-angle variants so clearance
                                       ;; can dodge crowded spots
                                       (mapcan (lambda (x) (list (+ x 0.26)
                                                                 (- x 0.26)))
                                               cands0)))
                        (preferred (when (and (gethash a ring-atoms)
                                              (gethash a cent))
                                     (%ang (%v- (gethash a pos)
                                                (gethash a cent))))))
                   (dolist (n free)
                     (let* ((straight
                              ;; chain continuation: parent A has exactly
                              ;; one other placed neighbor G; turn +/- 60
                              ;; degrees from the G->A axis (alternating)
                              (let ((g (find-if (lambda (x)
                                                  (and (gethash x pos)
                                                       (not (eq x n))
                                                       (not (member x free))))
                                                (gethash a nb))))
                                (when (and g
                                           (= (length free) 1)
                                           (= (count-if (lambda (x) (gethash x pos))
                                                        (gethash a nb))
                                              1))
                                  (let ((base (%ang (%v- (gethash a pos)
                                                         (gethash g pos))))
                                        (sgn (- (or (gethash a turn-sign) 1))))
                                    (setf (gethash n turn-sign) sgn)
                                    (+ base (* sgn (/ pi 3)))))))
                            (dir (or straight
                                     (let ((bd nil) (bc -1e9))
                                       (dolist (ang cands)
                                         (let* ((d (cons (cos ang) (sin ang)))
                                                (p (%v+ (gethash a pos)
                                                        (%v* d *mol-bond-length*)))
                                                (c (+ (clearance p a)
                                                      (if preferred
                                                          (* 2.0
                                                             (cos (- ang preferred)))
                                                          0.0))))
                                           (when (> c bc)
                                             (setf bc c bd ang))))
                                       bd)))
                            (d (cons (cos dir) (sin dir))))
                       (setf (gethash n pos)
                             (%v+ (gethash a pos) (%v* d *mol-bond-length*))
                             (gethash n parents) a
                             (gethash n queued) t)
                       (let ((cyc (gethash n atom-cycle)))
                         (when cyc
                           ;; first atom of an unplaced ring: lay the whole
                           ;; ring as a regular polygon from here
                           (remhash n atom-cycle)
                           (%place-cycle-spiro cyc pos nb d)
                           (dolist (x cyc)
                             (setf (gethash x queued) t)
                             (unless (gethash x cent)
                               ;; register centroid for radial substituents
                               (let ((pts (mapcar (lambda (y) (gethash y pos)) cyc)))
                                 (setf (gethash x cent)
                                       (cons (/ (reduce #'+ (mapcar #'car pts)) (length pts))
                                             (/ (reduce #'+ (mapcar #'cdr pts)) (length pts))))
                                 (setf (gethash x ring-atoms) t))))
                           (dolist (x cyc)
                             (setf (gethash x atom-cycle) nil)
                             ;; push so their own substituents get placed
                             (push x queue))))
                       (push n queue)
                       (setf cands (remove dir cands :test #'=)))))))
    (values parents ring-atoms)))

(defun %descendants (a parents)
  "A and every atom whose placement tree path goes through A."
  (let ((out (list a))
        (more t))
    (loop while more
          do (setf more nil)
             (maphash (lambda (child parent)
                        (when (and (member parent out :test #'eq)
                                   (not (member child out :test #'eq)))
                          (push child out)
                          (setf more t)))
                      parents))
    out))

(defun %flip-pass (atoms pos nb parents ring-atoms)
  "Depiction cleanup: reflect chain subtrees across the line through
each degree-2 atom's neighbors when it reduces the overlap score."
  (let ((improved t) (flips 0))
    (loop while (and improved (< flips 24))
          do (setf improved nil)
             (dolist (a atoms)
               (let ((p (gethash a pos)))
                 (when p
                   (let* ((nbs (gethash a nb))
                          (placed-nbs (remove-if-not (lambda (n) (gethash n pos)) nbs)))
                     ;; only clean chain middles: exactly two neighbors,
                     ;; both placed, not a ring atom itself
                     (when (and (= (length nbs) 2) (= (length placed-nbs) 2)
                                (not (gethash a ring-atoms)))
                       (let* ((p1 (gethash (first placed-nbs) pos))
                              (p2 (gethash (second placed-nbs) pos))
                              (u (%unit (%v- p2 p1)))
                              (desc (remove-if-not (lambda (x) (gethash x pos))
                                                   (%descendants a parents)))
                              (before (%overlap-score atoms pos nb)))
                         ;; reflect the subtree across line p1-p2
                         (dolist (x desc)
                           (let* ((r (%v- (gethash x pos) p1))
                                  (proj (%v* u (%dot r u)))
                                  (refl (%v+ p1 (%v- (%v* proj 2.0) r))))
                             (setf (gethash x pos) refl)))
                         (let ((after (%overlap-score atoms pos nb)))
                           (if (< after before)
                               (setf improved t flips (1+ flips))
                               ;; revert
                               (dolist (x desc)
                                 (let* ((r (%v- (gethash x pos) p1))
                                        (proj (%v* u (%dot r u)))
                                        (refl (%v+ p1 (%v- (%v* proj 2.0) r))))
                                   (setf (gethash x pos) refl))))))))))))
    flips))

(defun %polish-terminals (atoms pos nb)
  "Final polish: rotate each terminal atom (single heavy neighbor)
  around its parent in small steps when it buys clearance. Keeps all
  geometry standard; only terminal bond angles flex a little."
  (flet ((clearance (p skip1 skip2)
           (let ((best 1e9))
             (maphash (lambda (b q)
                        (unless (or (eq b skip1) (eq b skip2))
                          (setf best (min best (%vlen (%v- p q))))))
                      pos)
             best)))
    (dolist (a atoms)
      (let ((p (first (gethash a nb))))
        (when (and (= (length (gethash a nb)) 1)
                   (gethash a pos) (gethash p pos))
          (let* ((base (%ang (%v- (gethash a pos) (gethash p pos))))
                 (best-c (clearance (gethash a pos) a p))
                 (best-p (gethash a pos)))
            (dolist (da (list -0.5 -0.35 -0.2 -0.1 0.1 0.2 0.35 0.5))
              (let* ((ang (+ base da))
                     (q (%v+ (gethash p pos)
                             (%v* (cons (cos ang) (sin ang)) *mol-bond-length*))))
                (let ((c (clearance q a p)))
                  (when (> c best-c) (setf best-c c best-p q)))))
            (setf (gethash a pos) best-p)))))))

(defun %orient-horizontal (pos)
  "Canonical depiction orientation: rotate so the molecule's principal
axis runs horizontally (reference drawings of long molecules like
cephalostatin spread left-to-right)."
  (let* ((pts nil)
         (n 0) (mx 0.0) (my 0.0))
    (maphash (lambda (a p)
               (declare (ignore a))
               (push p pts) (incf n)
               (incf mx (car p)) (incf my (cdr p)))
             pos)
    (when (>= n 3)
      (let* ((cx (/ mx n)) (cy (/ my n))
             (sxx (reduce #'+ (mapcar (lambda (p) (expt (- (car p) cx) 2)) pts)))
             (syy (reduce #'+ (mapcar (lambda (p) (expt (- (cdr p) cy) 2)) pts)))
             (sxy (reduce #'+ (mapcar (lambda (p) (* (- (car p) cx) (- (cdr p) cy))) pts))))
        (when (> (+ sxx syy) 1e-6)
          (let ((theta (* 0.5 (atan (/ (* 2 sxy) (- sxx syy))))))
            (maphash (lambda (a p)
                       (let* ((dx (- (car p) cx)) (dy (- (cdr p) cy))
                              (c (cos theta)) (sn (sin theta)))
                         (setf (gethash a pos)
                               (cons (+ cx (- (* c dx) (* sn dy)))
                                     (+ cy (+ (* sn dx) (* c dy)))))))
                     pos)))))))

(defun %layout (mol &key (iterations 0))
  (declare (ignore iterations))
  (let* ((atoms (%heavy-atoms mol))
         (nb (%neighbors-map mol atoms))
         (cycles (%cycles mol atoms))
         (pos (make-hash-table :test 'eq)))
    (when atoms
      ;; 1. ring templates: smallest ring first, then fuse ring systems
      ;;    along shared edges
      (when cycles (%place-cycle-fresh (first cycles) pos))
      (loop
        (let ((progress nil))
          (dolist (cyc (rest cycles))
            (let ((placed (count-if (lambda (a) (gethash a pos)) cyc)))
              (cond ((and (plusp placed)
                          (notevery (lambda (a) (gethash a pos)) cyc))
                     (when (if (= placed 1)
                               ;; one shared atom: spiro junction
                               (%place-cycle-spiro cyc pos nb)
                               (%place-cycle-fused cyc pos (%placed-centroid pos)))
                       (setf progress t)))
                    ((zerop placed)
                     ;; ring linked by a single bond (nicotine-style)
                     (when (%place-cycle-linked cyc pos nb)
                       (setf progress t))))))
          (unless progress (return))))
      ;; 2. chains and substituents with standardized 120-degree geometry
      ;;    (see %place-chains)
      (multiple-value-bind (parents ring-atoms)
          (%place-chains mol atoms nb cycles pos)
        ;; 3. flip-based overlap cleanup: reflect chain subtrees across
        ;;    their attachment lines until no flip helps
        (%flip-pass atoms pos nb parents ring-atoms)
        ;; 4. terminal polish: nudge lone substituents into free space
        (%polish-terminals atoms pos nb)
        ;; 5. dense multi-ring systems (steroids & friends): a short
        ;;    relaxation spreads the remaining contacts; simple molecules
        ;;    keep their exact template geometry
        (when (>= (length cycles) 4)
          (%relax mol pos atoms :iterations 480))
        ;; canonical orientation: principal axis horizontal
        (%orient-horizontal pos)))
    pos))

;;; --------------------------------------------------------------------
;;; SVG

(defun %atom-hcount (mol a)
  (count-if (lambda (n) (string= (%smiles-sym n) "H"))
            (mapcar (lambda (b) (other-end b a)) (find-bonds-containing mol a))))

(defun %fmt (x) (format nil "~,1f" x))

(defun %svg-escape (s)
  (with-output-to-string (out)
    (loop for c across s
          do (case c
               (#\" (princ "&quot;" out))
               (#\< (princ "&lt;" out))
               (#\> (princ "&gt;" out))
               (#\& (princ "&amp;" out))
               (t (princ c out))))))

(defun %aromatic-accents (mol pos)
  "Eq-hash of aromatic bonds that get an inner accent line: a matching
over each ring's aromatic edges (never two accents sharing an atom), so
benzene draws three alternating inner strokes and fused rings never
draw adjacent double bonds. Values are the ring centroid, used to pick
the inner side."
  (let ((acc (make-hash-table :test 'eq))
        (taken (make-hash-table :test 'eq)))
    ;; larger rings claim their accents first, fused rings fill in
    (dolist (cyc (reverse (%cycles mol (%heavy-atoms mol))))
      (let* ((n (length cyc))
             (cx (/ (reduce #'+ (mapcar (lambda (a) (car (gethash a pos))) cyc)) n))
             (cy (/ (reduce #'+ (mapcar (lambda (a) (cdr (gethash a pos))) cyc)) n))
             (ring-edges
              (loop for i below n
                    for a = (nth i cyc)
                    for b = (nth (mod (1+ i) n) cyc)
                    collect (find-if
                             (lambda (e)
                               (or (and (eq (slot-value e 'epigraph:node1) a)
                                        (eq (slot-value e 'epigraph:node2) b))
                                   (and (eq (slot-value e 'epigraph:node1) b)
                                        (eq (slot-value e 'epigraph:node2) a))))
                             (graph:edges mol))))
             (marked (remove-if-not
                      (lambda (e) (= (or (slot-value e 'order) 1) 1.5))
                      (remove nil ring-edges))))
        (dolist (be marked)
          (let ((n1 (slot-value be 'epigraph:node1))
                (n2 (slot-value be 'epigraph:node2)))
            (when (and (not (gethash n1 taken))
                       (not (gethash n2 taken)))
              (setf (gethash n1 taken) t
                    (gethash n2 taken) t)
              (setf (gethash be acc) (cons cx cy)))))))
    acc))

(defun %bond-lines (mol b pos &optional (accents (make-hash-table :test 'eq)))
  "SVG snippet for one heavy-heavy bond, between label-aware endpoints."
  (flet ((pt (a off)
           (let* ((p (gethash a pos))
                  (el (and (slot-boundp a 'element) (element a)))
                  (r (if (and el (string/= (id el) "C")) (max 7.0 (* 12.5 *mol-scale*)) 0.0)))
             (cons (+ (car p) off) (+ (cdr p) off r 0.0)))))
    (let* ((a1 (slot-value b 'epigraph:node1))
           (a2 (slot-value b 'epigraph:node2))
           (p1 (gethash a1 pos)) (p2 (gethash a2 pos))
           (dx (- (car p2) (car p1))) (dy (- (cdr p2) (cdr p1)))
           (len (max 1.0 (sqrt (+ (* dx dx) (* dy dy)))))
           (nx (/ (- dy) len)) (ny (/ dx len))
           (order (or (slot-value b 'order) 1)))
      (labels ((labeled (a)
                 (let ((el (and (slot-boundp a 'element) (element a))))
                   (and el (string/= (id el) "C"))))
               (line (o1 o2 &key dash (color "#8b949e"))
                 ;; shorten at labeled (hetero) endpoints so bonds stop at
                 ;; the label circle instead of running through the text
                 (let* ((ux (/ dx len)) (uy (/ dy len))
                        (t1 (if (labeled a1) (max 6.5 (* 11.5 *mol-scale*)) 0.0))
                        (t2 (if (labeled a2) (max 6.5 (* 11.5 *mol-scale*)) 0.0))
                        (x1 (+ (+ (car p1) (* t1 ux)) (* o1 nx)))
                        (y1 (+ (+ (cdr p1) (* t1 uy)) (* o1 ny)))
                        (x2 (+ (- (car p2) (* t2 ux)) (* o2 nx)))
                        (y2 (+ (- (cdr p2) (* t2 uy)) (* o2 ny))))
                   (format nil "<line x1=\"~a\" y1=\"~a\" x2=\"~a\" y2=\"~a\" stroke=\"~a\" stroke-width=\"~a\"~a/>"
                           (%fmt x1) (%fmt y1) (%fmt x2) (%fmt y2) color
                           (if (= order 1.5) 1.6 1.9)
                           (if dash (format nil " stroke-dasharray=\"~a\"" dash) ""))))
               (trim (o) o))
        (declare (ignore trim))
        (cond
          ((= order 2)
           (concatenate 'string (line -3.2 -3.2) (line 3.2 3.2)))
          ((= order 3)
           (concatenate 'string (line 0 0) (line -4 -4) (line 4 4)))
          ((and (= order 1.5) (gethash b accents))
           ;; solid outer bond + short aromatic inner line (alternating)
           (let* ((in1 (list (+ (car p1) (* 0.20 dx)) (+ (cdr p1) (* 0.20 dy))))
                  (in2 (list (+ (car p1) (* 0.80 dx)) (+ (cdr p1) (* 0.80 dy))))
                  (cen (gethash b accents))
                  ;; offset the inner line toward the ring centroid so the
                  ;; accent reads as an inner double-bond stroke
                  (sgn (if cen
                           (signum (+ (* nx (- (car cen) (/ (+ (car p1) (car p2)) 2.0)))
                                      (* ny (- (cdr cen) (/ (+ (cdr p1) (cdr p2)) 2.0)))))
                           1.0))
                  (ox (* 4.5 nx sgn)) (oy (* 4.5 ny sgn)))
             (concatenate 'string
                          (line 0 0)
                          (format nil "<line x1=\"~a\" y1=\"~a\" x2=\"~a\" y2=\"~a\" stroke=\"#6ea8dc\" stroke-width=\"1.6\"/>"
                                  (%fmt (+ (first in1) ox)) (%fmt (+ (second in1) oy))
                                  (%fmt (+ (first in2) ox)) (%fmt (+ (second in2) oy))))))
          ((= order 1.5) (line 0 0))
          (t (line 0 0)))))))

(defun molecule-svg (mol &key (width 420) (padding 28))
  "An SVG string depicting MOL (2-D force-directed layout, heavy atoms;
implicit hydrogens folded into hetero labels)."
  (let* ((pos (%layout mol))
         (atoms (%heavy-atoms mol))
         (bonds (remove-if
                 (lambda (b) (or (string= (%smiles-sym (slot-value b 'epigraph:node1)) "H")
                                 (string= (%smiles-sym (slot-value b 'epigraph:node2)) "H")))
                 (graph:edges mol))))
    (if (or (null atoms) (null pos)
            (not (gethash (first atoms) pos)))
        "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"120\" height=\"40\"><text x=\"6\" y=\"24\" font-size=\"12\" fill=\"#8b949e\">(empty molecule)</text></svg>"
        (let* ((xs (mapcar (lambda (a) (car (gethash a pos))) atoms))
               (ys (mapcar (lambda (a) (cdr (gethash a pos))) atoms))
               (minx (reduce #'min xs)) (maxx (reduce #'max xs))
               (miny (reduce #'min ys)) (maxy (reduce #'max ys))
               (w (max 1 (- maxx minx))) (h (max 1 (- maxy miny)))
               (scale (/ (- width (* 2 padding)) (max w h 1)))
               (view-w (max 60 (+ (* w scale) (* 2 padding))))
               (view-h (max 60 (+ (* h scale) (* 2 padding)))))
          (setf *mol-scale* scale)
          ;; rescale into the viewBox
          (maphash (lambda (a p)
                     (setf (gethash a pos)
                           (cons (+ padding (* (- (car p) minx) scale))
                                 (+ padding (* (- (cdr p) miny) scale)))))
                   pos)
          (with-output-to-string (out)
            (format out "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"~a\" height=\"~a\" viewBox=\"0 0 ~a ~a\" font-family=\"ui-monospace,Menlo,monospace\">~%"
                    (%fmt view-w) (%fmt view-h) (%fmt view-w) (%fmt view-h)
                    )
            (format out "<rect width=\"100%\" height=\"100%\" fill=\"#0d0f14\" rx=\"6\"/>~%")
            (let ((acc (%aromatic-accents mol pos)))
              (dolist (b bonds) (princ (%bond-lines mol b pos acc) out)))
            (dolist (a atoms)
              (let* ((p (gethash a pos))
                     (el (and (slot-boundp a 'element) (element a)))
                     (sym (if el (id el) "?"))
                     (hs (%atom-hcount mol a)))
                (unless (and el (string= sym "C"))
                  (let* ((r0 (max 7.0 (* 12.5 *mol-scale*)))
                         ;; if two labels would touch at r0, shrink them
                         ;; (floor 6.5) until they clear or give up
                         (r1 (block shrink
                                (loop for r = r0 then (* r 0.8)
                                      repeat 5
                                      do (let ((pts (mapcar (lambda (x) (gethash x pos))
                                                            (remove-if (lambda (x)
                                                                         (let ((e (and (slot-boundp x 'element) (element x))))
                                                                           (and e (string= (id e) "C"))))
                                                                       atoms))))
                                           (unless (loop for (p1 . rest) on pts
                                                         thereis (dolist (p2 rest)
                                                                   (when (< (%vlen (%v- p1 p2)) (+ (* 2 r) 1.0))
                                                                     (return t))))
                                             (return-from shrink r)))
                                      finally (return (* r0 0.33)))))
                         (chg (let ((c (charge a)))
                                (cond ((or (null c) (zerop c)) "")
                                      ((plusp c)
                                       (format nil "+~a" (if (= c 1) "" c)))
                                      (t
                                       (format nil "-~a" (if (= c -1) "" (- c)))))))
                         (label (concatenate 'string sym
                                             (if (plusp hs)
                                                 (format nil "H~a" (if (> hs 1) hs ""))
                                                 "")
                                             ;; formal charge, e.g. [n+] -> N+
                                             (if (and (> (length chg) 1)
                                                      (or (string= sym "N")
                                                          (string= sym "O")
                                                          (string= sym "S")))
                                                 (subseq chg 1)
                                                 chg))))
                    (format out "<circle cx=\"~a\" cy=\"~a\" r=\"~a\" fill=\"#0d0f14\" stroke=\"#8b949e\" stroke-width=\"1\"/>"
                            (%fmt (car p)) (%fmt (cdr p))
                            (%fmt r1))
                    (format out "<text x=\"~a\" y=\"~a\" text-anchor=\"middle\" dominant-baseline=\"central\" font-size=\"~a\" fill=\"#e6edf3\">~a</text>~%"
                            (%fmt (car p)) (%fmt (cdr p))
                            (%fmt (max 7.0 (* (if (> (length label) 2) 9.5 11.5)
                                              *mol-scale*
                                              (/ r1 (max 0.01 (* 12.5 *mol-scale*))))))
                            (%svg-escape label))))))
            (princ "</svg>" out))))))

;;; --------------------------------------------------------------------
;;; the ;;PLOT64 channel

(defparameter *base64-alphabet* "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/")

(defun %base64 (string)
  (with-output-to-string (out)
    (loop with bytes = (map 'vector #'char-code string)
          for i from 0 below (length bytes) by 3
          for b1 = (aref bytes i)
          for b2 = (when (< (1+ i) (length bytes)) (aref bytes (1+ i)))
          for b3 = (when (< (+ 2 i) (length bytes)) (aref bytes (+ 2 i)))
          for n = (+ (ash b1 16) (ash (or b2 0) 8) (or b3 0))
          do (princ (char *base64-alphabet* (logand (ash n -18) 63)) out)
             (princ (char *base64-alphabet* (logand (ash n -12) 63)) out)
             (princ (if b2 (char *base64-alphabet* (logand (ash n -6) 63)) #\=) out)
             (princ (if b3 (char *base64-alphabet* (logand n 63)) #\=) out))))

(defun %cl-string-payload (svg)
  "The payload format the page's plot decoder reads: one double-quoted,
backslash-escaped string (the SVG plays the role of the gnuplot script)."
  (with-output-to-string (out)
    (princ #\" out)
    (loop for c across svg
          do (case c
               (#\" (princ "\\\"" out))
               (#\\ (princ "\\\\" out))
               (t (princ c out))))
    (princ #\" out)))

(defun %emit-plot-svg (svg)
  (format t "~&;;PLOT64 ~A~%" (%base64 (%cl-string-payload svg))))

;;; --------------------------------------------------------------------
;;; the public entry points

(defun show-molecule (mol &key (width 420))
  "Draw MOL in its session cell as an SVG structure diagram, and return
the molecule."
  (%emit-plot-svg (molecule-svg mol :width width))
  mol)

(defun show-smiles (smiles &key name (width 420) (add-implicit-hydrogens t))
  "Parse a SMILES string, draw the molecule in the session cell as an SVG
structure diagram, and return the molecule."
  (let ((mol (parse-smiles-string smiles :name (or name "smiles")
                                  :add-implicit-hydrogens add-implicit-hydrogens)))
    (show-molecule mol :width width)))
