;;; file: chemicl-svg.lisp
;;;
;;; 2-D depiction of chemicl molecules as SVG, for
;;;   (chemicl:show-smiles "CCO")            ; parse + draw + emit marker
;;;   (chemicl:show-molecule *caffeine*)     ; draw an existing molecule
;;;   (chemicl:molecule-svg mol)             ; just the SVG string
;;;
;;; Layout is force-directed (springs on bonds, repulsion between all
;;; atom pairs), seeded on a circle — good enough for notebook-sized
;;; molecules and engine-only: no JS, no gnuplot. The SVG travels to the
;;; page through the same ;;PLOT64 capture channel gnuplot plots use
;;; (the app recognizes a raw <svg> payload and renders it with the usual
;;; plot chrome, downloads included).
;;;
;;; Copyright (c) 2008-2014 Cyrus Harmon — molecule API (BSD, see
;;; COPYRIGHT-chemicl). This file: BSD, same terms.

(in-package #:chemicl)

;;; --------------------------------------------------------------------
;;; 2-D layout — force directed

(defparameter *mol-bond-length* 42.0
  "Preferred bond length in SVG units.")

(defparameter *mol-repulsion* 2400.0
  "Strength of the all-pairs repulsion (k² in Fruchterman-Reingold).")

(defun %heavy-atoms (mol)
  (remove-if (lambda (a) (string= (%smiles-sym a) "H"))
             (graph:map-nodes->list #'identity mol)))

(defun %layout (mol &key (iterations 400))
  "Positions (atom → (x . y)) for the heavy atoms of MOL."
  (let* ((atoms (%heavy-atoms mol))
         (n (length atoms))
         (pos (make-hash-table :test 'eq))
         (disp (make-hash-table :test 'eq)))
    (when (zerop n) (return-from %layout pos))
    ;; seed on a circle, golden-angle spiral so orders differ
    (loop for a in atoms
          for i from 0
          for ang = (* i 2.399963)
          for r = (* 12 (sqrt (1+ i)))
          do (setf (gethash a pos) (cons (* r (cos ang)) (* r (sin ang)))))
    (let ((bonds (remove-if
                  (lambda (b) (or (string= (%smiles-sym (slot-value b 'epigraph:node1)) "H")
                                  (string= (%smiles-sym (slot-value b 'epigraph:node2)) "H")))
                  (graph:edges mol))))
      (loop repeat iterations
            for temp = 0.0 then (max 0.5 (* 0.995 temp))
            do
            (flet ((fx (a) (car (gethash a pos)))
                   (fy (a) (cdr (gethash a pos))))
              ;; repulsion (displacements reset for every atom first)
              (dolist (a atoms) (setf (gethash a disp) (cons 0.0 0.0)))
              (loop for (a . rest) on atoms
                    do
                    (dolist (b rest)
                      (let* ((dx (- (fx a) (fx b)))
                             (dy (- (fy a) (fy b)))
                             (d (max 1.0 (sqrt (+ (* dx dx) (* dy dy))))))
                        (let ((f (/ *mol-repulsion* (* d d))))
                          (incf (car (gethash a disp)) (* f (/ dx d)))
                          (incf (cdr (gethash a disp)) (* f (/ dy d)))
                          (incf (car (gethash b disp)) (- (* f (/ dx d))))
                          (incf (cdr (gethash b disp)) (- (* f (/ dy d))))))))
              ;; springs
              (dolist (b bonds)
                (let* ((a1 (slot-value b 'epigraph:node1))
                       (a2 (slot-value b 'epigraph:node2))
                       (dx (- (fx a1) (fx a2)))
                       (dy (- (fy a1) (fy a2)))
                       (d (max 1.0 (sqrt (+ (* dx dx) (* dy dy)))))
                       ;; aromatic bonds pull a little tighter
                       (want (if (= (or (slot-value b 'order) 1) 1.5)
                                 (* 0.92 *mol-bond-length*) *mol-bond-length*))
                       (f (- d want)))
                  (incf (car (gethash a1 disp)) (- (* f (/ dx d))))
                  (incf (cdr (gethash a1 disp)) (- (* f (/ dy d))))
                  (incf (car (gethash a2 disp)) (* f (/ dx d)))
                  (incf (cdr (gethash a2 disp)) (* f (/ dy d)))))
              ;; apply, clamped
              (dolist (a atoms)
                (let* ((d (gethash a disp))
                       (mag (max 1.0 (sqrt (+ (expt (car d) 2) (expt (cdr d) 2)))))
                       (lim (min mag (if (zerop temp) 6.0 (max 1.0 temp)))))
                  (incf (car (gethash a pos)) (* (/ (car d) mag) lim))
                  (incf (cdr (gethash a pos)) (* (/ (cdr d) mag) lim)))))))
    pos))

;;; --------------------------------------------------------------------
;;; SVG

(defun %atom-hcount (mol a)
  (count-if (lambda (n) (string= (%smiles-sym n) "H"))
            (mapcar (lambda (b) (other-end b a)) (find-bonds-containing mol a))))

(defun %fmt (x) (format nil "~,1f" x))

(defun %svg-escape (s)
  (with-output-to-string (out)
    (loop for c across s
          do (case c
               (#\" (princ "&quot;" out))
               (#\< (princ "&lt;" out))
               (#\> (princ "&gt;" out))
               (#\& (princ "&amp;" out))
               (t (princ c out))))))

(defun %bond-lines (mol b pos)
  "SVG snippet for one heavy-heavy bond, between label-aware endpoints."
  (flet ((pt (a off)
           (let* ((p (gethash a pos))
                  (el (and (slot-boundp a 'element) (element a)))
                  (r (if (and el (string/= (id el) "C")) 12.5 0.0)))
             (cons (+ (car p) off) (+ (cdr p) off r 0.0)))))
    (let* ((a1 (slot-value b 'epigraph:node1))
           (a2 (slot-value b 'epigraph:node2))
           (p1 (gethash a1 pos)) (p2 (gethash a2 pos))
           (dx (- (car p2) (car p1))) (dy (- (cdr p2) (cdr p1)))
           (len (max 1.0 (sqrt (+ (* dx dx) (* dy dy)))))
           (nx (/ (- dy) len)) (ny (/ dx len))
           (order (or (slot-value b 'order) 1)))
      (labels ((line (o1 o2 &key dash (color "#8b949e"))
                 (let ((x1 (+ (car p1) (* o1 nx))) (y1 (+ (cdr p1) (* o1 ny)))
                       (x2 (+ (car p2) (* o2 nx))) (y2 (+ (cdr p2) (* o2 ny))))
                   (format nil "<line x1=\"~a\" y1=\"~a\" x2=\"~a\" y2=\"~a\" stroke=\"~a\" stroke-width=\"~a\"~a/>"
                           (%fmt x1) (%fmt y1) (%fmt x2) (%fmt y2) color
                           (if (= order 1.5) 1.6 1.9)
                           (if dash (format nil " stroke-dasharray=\"~a\"" dash) ""))))
               (trim (o) o))
        (declare (ignore trim))
        (cond
          ((= order 2)
           (concatenate 'string (line -3.2 -3.2) (line 3.2 3.2)))
          ((= order 3)
           (concatenate 'string (line 0 0) (line -4 -4) (line 4 4)))
          ((= order 1.5)
           ;; solid outer bond + short aromatic inner line
           (let* ((in1 (list (+ (car p1) (* 0.18 dx)) (+ (cdr p1) (* 0.18 dy))))
                  (in2 (list (+ (car p1) (* 0.82 dx)) (+ (cdr p1) (* 0.82 dy))))
                  (ox (* 4.5 nx)) (oy (* 4.5 ny)))
             (concatenate 'string
                          (line 0 0)
                          (format nil "<line x1=\"~a\" y1=\"~a\" x2=\"~a\" y2=\"~a\" stroke=\"#6ea8dc\" stroke-width=\"1.6\"/>"
                                  (%fmt (+ (first in1) ox)) (%fmt (+ (second in1) oy))
                                  (%fmt (+ (first in2) ox)) (%fmt (+ (second in2) oy))))))
          (t (line 0 0)))))))

(defun molecule-svg (mol &key (width 420) (padding 28))
  "An SVG string depicting MOL (2-D force-directed layout, heavy atoms;
implicit hydrogens folded into hetero labels)."
  (let* ((pos (%layout mol))
         (atoms (%heavy-atoms mol))
         (bonds (remove-if
                 (lambda (b) (or (string= (%smiles-sym (slot-value b 'epigraph:node1)) "H")
                                 (string= (%smiles-sym (slot-value b 'epigraph:node2)) "H")))
                 (graph:edges mol))))
    (if (or (null atoms) (null pos)
            (not (gethash (first atoms) pos)))
        "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"120\" height=\"40\"><text x=\"6\" y=\"24\" font-size=\"12\" fill=\"#8b949e\">(empty molecule)</text></svg>"
        (let* ((xs (mapcar (lambda (a) (car (gethash a pos))) atoms))
               (ys (mapcar (lambda (a) (cdr (gethash a pos))) atoms))
               (minx (reduce #'min xs)) (maxx (reduce #'max xs))
               (miny (reduce #'min ys)) (maxy (reduce #'max ys))
               (w (max 1 (- maxx minx))) (h (max 1 (- maxy miny)))
               (scale (/ (- width (* 2 padding)) (max w h 1)))
               (view-w (max 60 (+ (* w scale) (* 2 padding))))
               (view-h (max 60 (+ (* h scale) (* 2 padding)))))
          ;; rescale into the viewBox
          (maphash (lambda (a p)
                     (setf (gethash a pos)
                           (cons (+ padding (* (- (car p) minx) scale))
                                 (+ padding (* (- (cdr p) miny) scale)))))
                   pos)
          (with-output-to-string (out)
            (format out "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"~a\" height=\"~a\" viewBox=\"0 0 ~a ~a\" font-family=\"ui-monospace,Menlo,monospace\">~%"
                    (%fmt view-w) (%fmt view-h) (%fmt view-w) (%fmt view-h)
                    )
            (format out "<rect width=\"100%\" height=\"100%\" fill=\"#0d0f14\" rx=\"6\"/>~%")
            (dolist (b bonds) (princ (%bond-lines mol b pos) out))
            (dolist (a atoms)
              (let* ((p (gethash a pos))
                     (el (and (slot-boundp a 'element) (element a)))
                     (sym (if el (id el) "?"))
                     (hs (%atom-hcount mol a)))
                (unless (and el (string= sym "C"))
                  (let ((label (if (plusp hs)
                                   (format nil "~aH~a" sym (if (> hs 1) hs ""))
                                   sym)))
                    (format out "<circle cx=\"~a\" cy=\"~a\" r=\"12.5\" fill=\"#0d0f14\" stroke=\"#8b949e\" stroke-width=\"1\"/>"
                            (%fmt (car p)) (%fmt (cdr p)))
                    (format out "<text x=\"~a\" y=\"~a\" text-anchor=\"middle\" dominant-baseline=\"central\" font-size=\"~a\" fill=\"#e6edf3\">~a</text>~%"
                            (%fmt (car p)) (%fmt (cdr p))
                            (%fmt (if (> (length label) 2) 9.5 11.5))
                            (%svg-escape label))))))
            (princ "</svg>" out))))))

;;; --------------------------------------------------------------------
;;; the ;;PLOT64 channel

(defparameter *base64-alphabet* "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/")

(defun %base64 (string)
  (with-output-to-string (out)
    (loop with bytes = (map 'vector #'char-code string)
          for i from 0 below (length bytes) by 3
          for b1 = (aref bytes i)
          for b2 = (when (< (1+ i) (length bytes)) (aref bytes (1+ i)))
          for b3 = (when (< (+ 2 i) (length bytes)) (aref bytes (+ 2 i)))
          for n = (+ (ash b1 16) (ash (or b2 0) 8) (or b3 0))
          do (princ (char *base64-alphabet* (logand (ash n -18) 63)) out)
             (princ (char *base64-alphabet* (logand (ash n -12) 63)) out)
             (princ (if b2 (char *base64-alphabet* (logand (ash n -6) 63)) #\=) out)
             (princ (if b3 (char *base64-alphabet* (logand n 63)) #\=) out))))

(defun %cl-string-payload (svg)
  "The payload format the page's plot decoder reads: one double-quoted,
backslash-escaped string (the SVG plays the role of the gnuplot script)."
  (with-output-to-string (out)
    (princ #\" out)
    (loop for c across svg
          do (case c
               (#\" (princ "\\\"" out))
               (#\\ (princ "\\\\" out))
               (t (princ c out))))
    (princ #\" out)))

(defun %emit-plot-svg (svg)
  (format t "~&;;PLOT64 ~A~%" (%base64 (%cl-string-payload svg))))

;;; --------------------------------------------------------------------
;;; the public entry points

(defun show-molecule (mol &key (width 420))
  "Draw MOL in its session cell as an SVG structure diagram, and return
the molecule."
  (%emit-plot-svg (molecule-svg mol :width width))
  mol)

(defun show-smiles (smiles &key name (width 420) (add-implicit-hydrogens t))
  "Parse a SMILES string, draw the molecule in the session cell as an SVG
structure diagram, and return the molecule."
  (let ((mol (parse-smiles-string smiles :name (or name "smiles")
                                  :add-implicit-hydrogens add-implicit-hydrogens)))
    (show-molecule mol :width width)))
