;;; file: chemicl-svg.lisp
;;;
;;; 2-D depiction of chemicl molecules as SVG, for
;;;   (chemicl:show-smiles "CCO")            ; parse + draw + emit marker
;;;   (chemicl:show-molecule *caffeine*)     ; draw an existing molecule
;;;   (chemicl:molecule-svg mol)             ; just the SVG string
;;;
;;; Layout is force-directed (springs on bonds, repulsion between all
;;; atom pairs), seeded on a circle — good enough for notebook-sized
;;; molecules and engine-only: no JS, no gnuplot. The SVG travels to the
;;; page through the same ;;PLOT64 capture channel gnuplot plots use
;;; (the app recognizes a raw <svg> payload and renders it with the usual
;;; plot chrome, downloads included).
;;;
;;; Copyright (c) 2008-2014 Cyrus Harmon — molecule API (BSD, see
;;; COPYRIGHT-chemicl). This file: BSD, same terms.

(in-package #:chemicl)

;;; --------------------------------------------------------------------
;;; 2-D layout — depiction style (ring templates + zig-zag chains)

(defparameter *mol-bond-length* 42.0
  "Preferred bond length in SVG units.")

(defparameter *mol-repulsion* 2400.0
  "Strength of the all-pairs repulsion in the refinement pass.")

(defun %heavy-edges (mol)
  (remove-if (lambda (b) (or (string= (%smiles-sym (slot-value b 'epigraph:node1)) "H")
                             (string= (%smiles-sym (slot-value b 'epigraph:node2)) "H")))
             (graph:edges mol)))

(defun %neighbors-map (mol atoms)
  (let ((nb (make-hash-table :test 'eq)))
    (dolist (a atoms) (setf (gethash a nb) nil))
    (dolist (b (%heavy-edges mol))
      (let ((a1 (slot-value b 'epigraph:node1))
            (a2 (slot-value b 'epigraph:node2)))
        (push a2 (gethash a1 nb))
        (push a1 (gethash a2 nb))))
    (maphash (lambda (k v) (setf (gethash k nb) (nreverse v))) nb)
    nb))

(defun %heavy-atoms (mol)
  (remove-if (lambda (a) (string= (%smiles-sym a) "H"))
             (graph:map-nodes->list #'identity mol)))

(defun %cycles (mol atoms)
  "Smallest cycles through each non-tree edge (a good SSSR approximation
for depiction): DFS spanning forest, then each heavy non-tree edge closes
the cycle along its tree paths. Cycles come out in traversal order."
  (let ((parent (make-hash-table :test 'eq))
        (tree-edge (make-hash-table :test 'eq))
        (visited (make-hash-table :test 'eq))
        (nb (%neighbors-map mol atoms))
        (cycles '())
        (seen (make-hash-table :test 'equal)))
    (labels ((ancestors (a)
               (loop for x = a then (gethash x parent)
                     while x collect x))
             (dfs (a p)
               (setf (gethash a visited) t)
               (when p (setf (gethash a parent) p))
               (dolist (n (gethash a nb))
                 (cond ((not (gethash n visited))
                        (setf (gethash (cons a n) tree-edge) t
                              (gethash (cons n a) tree-edge) t)
                        (dfs n a))
                       ((and (not (eq n p))
                             (not (gethash (cons a n) tree-edge)))
                        ;; non-tree edge a-n: cycle = a..root ∩ reversed n..root
                        (let* ((pa (ancestors a))
                               (pn (ancestors n))
                               (common (loop for x in pa when (member x pn) collect x))
                               (root (first common))
                               (path-a (ldiff pa (member root pa)))
                               (path-n (ldiff pn (member root pn))))
                          (let ((cyc (append path-a (list root) (reverse path-n))))
                            (let ((key (sort (mapcar #'atom-name cyc) #'string<)))
                              (unless (gethash key seen)
                                (setf (gethash key seen) t)
                                (push cyc cycles))))))))))
      (dolist (a atoms) (unless (gethash a visited) (dfs a nil))))
    (sort cycles #'< :key #'length)))

(defun %v+ (p q) (cons (+ (car p) (car q)) (+ (cdr p) (cdr q))))
(defun %v- (p q) (cons (- (car p) (car q)) (- (cdr p) (cdr q))))
(defun %v* (p k) (cons (* (car p) k) (* (cdr p) k)))
(defun %vlen (p) (sqrt (+ (* (car p) (car p)) (* (cdr p) (cdr p)))))
(defun %unit (p)
  (let ((l (max 1e-9 (%vlen p)))) (cons (/ (car p) l) (/ (cdr p) l))))
(defun %rot (p ang)
  (cons (- (* (car p) (cos ang)) (* (cdr p) (sin ang)))
        (+ (* (car p) (sin ang)) (* (cdr p) (cos ang)))))

(defun %place-cycle-fresh (cycle pos)
  "Regular polygon at the origin, first edge horizontal."
  (let* ((n (length cycle))
         (R (/ *mol-bond-length* (* 2 (sin (/ pi n))))))
    (loop for a in cycle
          for k from 0
          for ang = (+ (/ pi 2) (* 2 pi (- k 0.5) (/ n)))
          do (setf (gethash a pos) (cons (* R (cos ang)) (* R (sin ang)))))))

(defun %place-cycle-fused (cycle pos placed-centroid)
  "Place the remaining atoms of CYCLE as a regular polygon when two of
its adjacent atoms are already placed (the shared edge of a fused ring);
pick the center on the far side from the placed mass."
  (let* ((n (length cycle))
         (R (/ *mol-bond-length* (* 2 (sin (/ pi n))))))
    ;; find the shared edge: two consecutive placed atoms in cycle order
    (loop for rest on (append cycle (list (first cycle)))
          when (and (gethash (first rest) pos) (gethash (second rest) pos))
            do (let* ((a1 (first rest)) (a2 (second rest))
                      (p1 (gethash a1 pos)) (p2 (gethash a2 pos))
                      (mid (%v* (%v+ p1 p2) 0.5))
                      (d (%vlen (%v- p2 p1)))
                      (h (sqrt (max 0.01 (- (* R R) (* d d 0.25)))))
                      (perp (let ((u (%unit (%v- p2 p1))))
                              (cons (- (cdr u)) (car u))))
                      (c1 (%v+ mid (%v* perp h)))
                      (c2 (%v+ mid (%v* perp (- h))))
                      (c (if (< (%vlen (%v- c1 (or placed-centroid '(0 . 0))))
                                (%vlen (%v- c2 (or placed-centroid '(0 . 0)))))
                             c2 c1)))
                 ;; walk the rest of the ring around the center, stepping
                 ;; the same angular direction as p1→p2
                 (let* ((u1 (atan (- (cdr p1) (cdr c)) (- (car p1) (car c))))
                        (u2 (atan (- (cdr p2) (cdr c)) (- (car p2) (car c))))
                        (step (let ((dd (- u2 u1)))
                                (if (> dd (- pi)) dd (+ dd (* 2 pi)))))
                        ;; angular direction must match cycle order a1→a2→a3…
                        (step (if (> (abs step) 1e-6) step
                                  (if (> u2 u1) (* 2 pi (- n) -1) 1.0)))
                        (idx (position a1 cycle)))
                   (loop for k from 2 below n
                         for a = (nth (mod (+ idx k) n) cycle)
                         for ang = (+ u2 (* step (- k 1)))
                         do (setf (gethash a pos)
                                  (%v+ c (cons (* R (cos ang)) (* R (sin ang))))))))
          and return t)))

(defun %placed-centroid (pos)
  (let ((x 0.0) (y 0.0) (n 0))
    (maphash (lambda (a p)
               (declare (ignore a))
               (incf x (car p)) (incf y (cdr p)) (incf n))
             pos)
    (if (zerop n) nil (cons (/ x n) (/ y n)))))


(defun %relax (mol pos atoms &key (iterations 160) (anchors nil))
  "Gentle force-directed refinement starting from the template
positions: bond springs keep the ring geometry, all-pairs repulsion
resolves collisions that chains and fused substituents can produce."
  (let ((bonds (%heavy-edges mol))
        (disp (make-hash-table :test 'eq)))
    (loop repeat iterations
          do
          (dolist (a atoms) (setf (gethash a disp) (cons 0.0 0.0)))
          (loop for (a . rest) on atoms
                do (dolist (b rest)
                     (let* ((pa (gethash a pos)) (pb (gethash b pos))
                            (dx (- (car pa) (car pb))) (dy (- (cdr pa) (cdr pb)))
                            (d (max 1.0 (sqrt (+ (* dx dx) (* dy dy)))))
                            (f (/ *mol-repulsion* (* d d))))
                       (incf (car (gethash a disp)) (* f (/ dx d)))
                       (incf (cdr (gethash a disp)) (* f (/ dy d)))
                       (incf (car (gethash b disp)) (- (* f (/ dx d))))
                       (incf (cdr (gethash b disp)) (- (* f (/ dy d)))))))
          (dolist (b bonds)
            (let* ((a1 (slot-value b 'epigraph:node1))
                   (a2 (slot-value b 'epigraph:node2))
                   (p1 (gethash a1 pos)) (p2 (gethash a2 pos))
                   (dx (- (car p1) (car p2))) (dy (- (cdr p1) (cdr p2)))
                   (d (max 1.0 (sqrt (+ (* dx dx) (* dy dy)))))
                   (want (if (= (or (slot-value b 'order) 1) 1.5)
                             (* 0.92 *mol-bond-length*) *mol-bond-length*))
                   (f (- (- d want) (* 0.5 (- d want)))))
              (incf (car (gethash a1 disp)) (* f (/ dx d)))
              (incf (cdr (gethash a1 disp)) (* f (/ dy d)))
              (incf (car (gethash a2 disp)) (- (* f (/ dx d))))
              (incf (cdr (gethash a2 disp)) (- (* f (/ dy d)))))))
          (dolist (a atoms)
            (let* ((d (gethash a disp))
                   (mag (max 1.0 (sqrt (+ (expt (car d) 2) (expt (cdr d) 2)))))
                   (lim (min mag 5.0)))
              (incf (car (gethash a pos)) (* (/ (car d) mag) lim))
              (incf (cdr (gethash a pos)) (* (/ (cdr d) mag) lim))))))

(defun %layout (mol &key (iterations 0))
  (declare (ignore iterations))
  (let* ((atoms (%heavy-atoms mol))
         (nb (%neighbors-map mol atoms))
         (cycles (%cycles mol atoms))
         (pos (make-hash-table :test 'eq)))
    (when atoms
      ;; 1. the smallest ring starts at the origin; ringless atoms chain later
      (when cycles (%place-cycle-fresh (first cycles) pos))
      ;; 2. repeatedly fuse rings that share an edge with placed atoms
      (loop
        (let ((progress nil))
          (dolist (cyc (rest cycles))
            (let ((placed (count-if (lambda (a) (gethash a pos)) cyc)))
              (when (and (plusp placed)
                         (notevery (lambda (a) (gethash a pos)) cyc))
                (when (%place-cycle-fused cyc pos (%placed-centroid pos))
                  (setf progress t)))))
          (unless progress (return))))
      ;; 3. chains: BFS from placed atoms, zig-zagging away; each new
      ;; atom picks the candidate direction that stays farthest from
      ;; every other placed atom (avoids crowding over rings)
      (let ((queue (mapcan (lambda (a) (when (gethash a pos) (list a))) atoms))
            (queued (make-hash-table :test 'eq)))
        (dolist (a queue) (setf (gethash a queued) t))
        (flet ((clearance (p parent)
                 (let ((best 1e9))
                   (maphash (lambda (b q)
                              (unless (eq b parent)
                                (setq best (min best (%vlen (%v- p q))))))
                            pos)
                   best)))
          (loop while queue
                for a = (pop queue)
                for free = (remove-if (lambda (n) (or (gethash n pos) (gethash n queued)))
                                      (gethash a nb))
                for incoming = (let ((placed-nb (find-if (lambda (n) (gethash n pos))
                                                         (gethash a nb))))
                                 (when (and placed-nb (gethash a pos))
                                   (%v- (gethash a pos) (gethash placed-nb pos))))
                for away = (if incoming (%v* (%unit incoming) (- 1.0))
                              (cons 1.0 0.0))
                do (loop for n in free
                         for i from 0
                         for spread0 = (* (- (* 2 i) (1- (length free))) (/ pi 6))
                         ;; sweep the full circle and keep the direction
                         ;; with the best clearance (distance to any other
                         ;; placed atom) plus a small preference for
                         ;; continuing away from the parent
                         for dir = (let ((bd nil) (bc -1e9))
                                     (dotimes (k 12)
                                       (let* ((ang (+ spread0 (* k (/ pi 6))))
                                              (d (%rot (cons 1.0 0.0) ang))
                                              (p (%v+ (gethash a pos) (%v* d *mol-bond-length*)))
                                              (c (+ (clearance p a)
                                                    (* 10.0 (+ (* (car d) (car away))
                                                               (* (cdr d) (cdr away)))))))
                                         (when (> c bc) (setq bc c bd d))))
                                     bd)
                         do (setf (gethash n pos) (%v+ (gethash a pos) (%v* dir *mol-bond-length*)))
                            (setf (gethash n queued) t)
                            (push n queue)))))
      ;; refinement: resolve collisions; ring atoms stay anchored so the
      ;; templates keep their regular geometry
      (let ((anchors (make-hash-table :test 'eq)))
        (dolist (cyc cycles) (dolist (a cyc) (setf (gethash a anchors) t)))
        (%relax mol pos atoms :anchors anchors)))
    pos))

;;; --------------------------------------------------------------------
;;; SVG

(defun %atom-hcount (mol a)
  (count-if (lambda (n) (string= (%smiles-sym n) "H"))
            (mapcar (lambda (b) (other-end b a)) (find-bonds-containing mol a))))

(defun %fmt (x) (format nil "~,1f" x))

(defun %svg-escape (s)
  (with-output-to-string (out)
    (loop for c across s
          do (case c
               (#\" (princ "&quot;" out))
               (#\< (princ "&lt;" out))
               (#\> (princ "&gt;" out))
               (#\& (princ "&amp;" out))
               (t (princ c out))))))

(defun %aromatic-accents (mol pos)
  "Eq-hash of aromatic bonds that get an inner accent line: a matching
over each ring's aromatic edges (never two accents sharing an atom), so
benzene draws three alternating inner strokes and fused rings never
draw adjacent double bonds. Values are the ring centroid, used to pick
the inner side."
  (let ((acc (make-hash-table :test 'eq))
        (taken (make-hash-table :test 'eq)))
    ;; larger rings claim their accents first, fused rings fill in
    (dolist (cyc (reverse (%cycles mol (%heavy-atoms mol))))
      (let* ((n (length cyc))
             (cx (/ (reduce #'+ (mapcar (lambda (a) (car (gethash a pos))) cyc)) n))
             (cy (/ (reduce #'+ (mapcar (lambda (a) (cdr (gethash a pos))) cyc)) n))
             (ring-edges
              (loop for i below n
                    for a = (nth i cyc)
                    for b = (nth (mod (1+ i) n) cyc)
                    collect (find-if
                             (lambda (e)
                               (or (and (eq (slot-value e 'epigraph:node1) a)
                                        (eq (slot-value e 'epigraph:node2) b))
                                   (and (eq (slot-value e 'epigraph:node1) b)
                                        (eq (slot-value e 'epigraph:node2) a))))
                             (graph:edges mol))))
             (marked (remove-if-not
                      (lambda (e) (= (or (slot-value e 'order) 1) 1.5))
                      (remove nil ring-edges))))
        (dolist (be marked)
          (let ((n1 (slot-value be 'epigraph:node1))
                (n2 (slot-value be 'epigraph:node2)))
            (when (and (not (gethash n1 taken))
                       (not (gethash n2 taken)))
              (setf (gethash n1 taken) t
                    (gethash n2 taken) t)
              (setf (gethash be acc) (cons cx cy)))))))
    acc))

(defun %bond-lines (mol b pos &optional (accents (make-hash-table :test 'eq)))
  "SVG snippet for one heavy-heavy bond, between label-aware endpoints."
  (flet ((pt (a off)
           (let* ((p (gethash a pos))
                  (el (and (slot-boundp a 'element) (element a)))
                  (r (if (and el (string/= (id el) "C")) 12.5 0.0)))
             (cons (+ (car p) off) (+ (cdr p) off r 0.0)))))
    (let* ((a1 (slot-value b 'epigraph:node1))
           (a2 (slot-value b 'epigraph:node2))
           (p1 (gethash a1 pos)) (p2 (gethash a2 pos))
           (dx (- (car p2) (car p1))) (dy (- (cdr p2) (cdr p1)))
           (len (max 1.0 (sqrt (+ (* dx dx) (* dy dy)))))
           (nx (/ (- dy) len)) (ny (/ dx len))
           (order (or (slot-value b 'order) 1)))
      (labels ((labeled (a)
                 (let ((el (and (slot-boundp a 'element) (element a))))
                   (and el (string/= (id el) "C"))))
               (line (o1 o2 &key dash (color "#8b949e"))
                 ;; shorten at labeled (hetero) endpoints so bonds stop at
                 ;; the label circle instead of running through the text
                 (let* ((ux (/ dx len)) (uy (/ dy len))
                        (t1 (if (labeled a1) 11.5 0.0))
                        (t2 (if (labeled a2) 11.5 0.0))
                        (x1 (+ (+ (car p1) (* t1 ux)) (* o1 nx)))
                        (y1 (+ (+ (cdr p1) (* t1 uy)) (* o1 ny)))
                        (x2 (+ (- (car p2) (* t2 ux)) (* o2 nx)))
                        (y2 (+ (- (cdr p2) (* t2 uy)) (* o2 ny))))
                   (format nil "<line x1=\"~a\" y1=\"~a\" x2=\"~a\" y2=\"~a\" stroke=\"~a\" stroke-width=\"~a\"~a/>"
                           (%fmt x1) (%fmt y1) (%fmt x2) (%fmt y2) color
                           (if (= order 1.5) 1.6 1.9)
                           (if dash (format nil " stroke-dasharray=\"~a\"" dash) ""))))
               (trim (o) o))
        (declare (ignore trim))
        (cond
          ((= order 2)
           (concatenate 'string (line -3.2 -3.2) (line 3.2 3.2)))
          ((= order 3)
           (concatenate 'string (line 0 0) (line -4 -4) (line 4 4)))
          ((and (= order 1.5) (gethash b accents))
           ;; solid outer bond + short aromatic inner line (alternating)
           (let* ((in1 (list (+ (car p1) (* 0.20 dx)) (+ (cdr p1) (* 0.20 dy))))
                  (in2 (list (+ (car p1) (* 0.80 dx)) (+ (cdr p1) (* 0.80 dy))))
                  (cen (gethash b accents))
                  ;; offset the inner line toward the ring centroid so the
                  ;; accent reads as an inner double-bond stroke
                  (sgn (if cen
                           (signum (+ (* nx (- (car cen) (/ (+ (car p1) (car p2)) 2.0)))
                                      (* ny (- (cdr cen) (/ (+ (cdr p1) (cdr p2)) 2.0)))))
                           1.0))
                  (ox (* 4.5 nx sgn)) (oy (* 4.5 ny sgn)))
             (concatenate 'string
                          (line 0 0)
                          (format nil "<line x1=\"~a\" y1=\"~a\" x2=\"~a\" y2=\"~a\" stroke=\"#6ea8dc\" stroke-width=\"1.6\"/>"
                                  (%fmt (+ (first in1) ox)) (%fmt (+ (second in1) oy))
                                  (%fmt (+ (first in2) ox)) (%fmt (+ (second in2) oy))))))
          ((= order 1.5) (line 0 0))
          (t (line 0 0)))))))

(defun molecule-svg (mol &key (width 420) (padding 28))
  "An SVG string depicting MOL (2-D force-directed layout, heavy atoms;
implicit hydrogens folded into hetero labels)."
  (let* ((pos (%layout mol))
         (atoms (%heavy-atoms mol))
         (bonds (remove-if
                 (lambda (b) (or (string= (%smiles-sym (slot-value b 'epigraph:node1)) "H")
                                 (string= (%smiles-sym (slot-value b 'epigraph:node2)) "H")))
                 (graph:edges mol))))
    (if (or (null atoms) (null pos)
            (not (gethash (first atoms) pos)))
        "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"120\" height=\"40\"><text x=\"6\" y=\"24\" font-size=\"12\" fill=\"#8b949e\">(empty molecule)</text></svg>"
        (let* ((xs (mapcar (lambda (a) (car (gethash a pos))) atoms))
               (ys (mapcar (lambda (a) (cdr (gethash a pos))) atoms))
               (minx (reduce #'min xs)) (maxx (reduce #'max xs))
               (miny (reduce #'min ys)) (maxy (reduce #'max ys))
               (w (max 1 (- maxx minx))) (h (max 1 (- maxy miny)))
               (scale (/ (- width (* 2 padding)) (max w h 1)))
               (view-w (max 60 (+ (* w scale) (* 2 padding))))
               (view-h (max 60 (+ (* h scale) (* 2 padding)))))
          ;; rescale into the viewBox
          (maphash (lambda (a p)
                     (setf (gethash a pos)
                           (cons (+ padding (* (- (car p) minx) scale))
                                 (+ padding (* (- (cdr p) miny) scale)))))
                   pos)
          (with-output-to-string (out)
            (format out "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"~a\" height=\"~a\" viewBox=\"0 0 ~a ~a\" font-family=\"ui-monospace,Menlo,monospace\">~%"
                    (%fmt view-w) (%fmt view-h) (%fmt view-w) (%fmt view-h)
                    )
            (format out "<rect width=\"100%\" height=\"100%\" fill=\"#0d0f14\" rx=\"6\"/>~%")
            (let ((acc (%aromatic-accents mol pos)))
              (dolist (b bonds) (princ (%bond-lines mol b pos acc) out)))
            (dolist (a atoms)
              (let* ((p (gethash a pos))
                     (el (and (slot-boundp a 'element) (element a)))
                     (sym (if el (id el) "?"))
                     (hs (%atom-hcount mol a)))
                (unless (and el (string= sym "C"))
                  (let ((label (if (plusp hs)
                                   (format nil "~aH~a" sym (if (> hs 1) hs ""))
                                   sym)))
                    (format out "<circle cx=\"~a\" cy=\"~a\" r=\"12.5\" fill=\"#0d0f14\" stroke=\"#8b949e\" stroke-width=\"1\"/>"
                            (%fmt (car p)) (%fmt (cdr p)))
                    (format out "<text x=\"~a\" y=\"~a\" text-anchor=\"middle\" dominant-baseline=\"central\" font-size=\"~a\" fill=\"#e6edf3\">~a</text>~%"
                            (%fmt (car p)) (%fmt (cdr p))
                            (%fmt (if (> (length label) 2) 9.5 11.5))
                            (%svg-escape label))))))
            (princ "</svg>" out))))))

;;; --------------------------------------------------------------------
;;; the ;;PLOT64 channel

(defparameter *base64-alphabet* "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/")

(defun %base64 (string)
  (with-output-to-string (out)
    (loop with bytes = (map 'vector #'char-code string)
          for i from 0 below (length bytes) by 3
          for b1 = (aref bytes i)
          for b2 = (when (< (1+ i) (length bytes)) (aref bytes (1+ i)))
          for b3 = (when (< (+ 2 i) (length bytes)) (aref bytes (+ 2 i)))
          for n = (+ (ash b1 16) (ash (or b2 0) 8) (or b3 0))
          do (princ (char *base64-alphabet* (logand (ash n -18) 63)) out)
             (princ (char *base64-alphabet* (logand (ash n -12) 63)) out)
             (princ (if b2 (char *base64-alphabet* (logand (ash n -6) 63)) #\=) out)
             (princ (if b3 (char *base64-alphabet* (logand n 63)) #\=) out))))

(defun %cl-string-payload (svg)
  "The payload format the page's plot decoder reads: one double-quoted,
backslash-escaped string (the SVG plays the role of the gnuplot script)."
  (with-output-to-string (out)
    (princ #\" out)
    (loop for c across svg
          do (case c
               (#\" (princ "\\\"" out))
               (#\\ (princ "\\\\" out))
               (t (princ c out))))
    (princ #\" out)))

(defun %emit-plot-svg (svg)
  (format t "~&;;PLOT64 ~A~%" (%base64 (%cl-string-payload svg))))

;;; --------------------------------------------------------------------
;;; the public entry points

(defun show-molecule (mol &key (width 420))
  "Draw MOL in its session cell as an SVG structure diagram, and return
the molecule."
  (%emit-plot-svg (molecule-svg mol :width width))
  mol)

(defun show-smiles (smiles &key name (width 420) (add-implicit-hydrogens t))
  "Parse a SMILES string, draw the molecule in the session cell as an SVG
structure diagram, and return the molecule."
  (let ((mol (parse-smiles-string smiles :name (or name "smiles")
                                  :add-implicit-hydrogens add-implicit-hydrogens)))
    (show-molecule mol :width width)))
