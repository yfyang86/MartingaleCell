;;; file: chemicl-smiles.lisp
;;;
;;; A self-contained SMILES parser and writer for the MartingaleCell port
;;; of chemicl. The upstream parser (smiles.lisp/smiles2/smiles3) is built
;;; on parser-combinators and fset, which are not vendored; this file
;;; replaces it with a plain recursive-descent parser over the same API:
;;;
;;;   (chemicl:parse-smiles-string "Cn1cnc2c1c(=O)n(C)c(=O)n2C")
;;;   (chemicl:write-smiles-string mol)
;;;
;;; Supported: organic-subset atoms (B C N O P S F Cl Br I, aromatic
;;; b c n o p s), bracket atoms ([13CH4], [nH], [Fe+2], [O-] ...), bonds
;;; - = # : (stereo / \ accepted, direction dropped), branches (including
;;; after a bond symbol), ring closures (digits, %nn, after a bond
;;; symbol), dots (fragments), and implicit-hydrogen completion from
;;; normal valences (the upstream default). NOT supported: stereochemistry
;;; (a 2-D atom/bond graph cannot carry it) and atom classes ([C:7]
;;; parses, the class is dropped); * parses as an unknown "R" element.
;;;
;;; Verified against RDKit 2026.03 over an 18-SMILES battery (formulas
;;; and masses) plus write/parse round-trips.
;;;
;;; Original API and semantics: Copyright (c) 2008-2014 Cyrus Harmon
;;; (BSD, see COPYRIGHT-chemicl). This implementation: BSD, same terms.

(in-package #:chemicl)

;;; --------------------------------------------------------------------
;;; parser state

(defstruct smiles-state
  (string "" :type string)
  (pos 0 :type integer)
  (molecule nil)
  (counter 0 :type integer)
  ;; ring-closure number → (atom bond-kind)
  (rings (make-hash-table :test 'eql))
  ;; atom → bracket H count (chemicl atoms have no hcount slot)
  (bracket-h (make-hash-table :test 'eq))
  ;; atom → aromatic-p (lowercase SMILES symbol)
  (aromatic (make-hash-table :test 'eq)))

(defparameter *smiles-organic*
  '(("B" 3) ("C" 4) ("N" 3) ("O" 2) ("P" 3) ("S" 2)
    ("F" 1) ("Cl" 1) ("Br" 1) ("I" 1))
  "Unbracketed SMILES elements and their normal valences.")

(defun %smiles-element-id (sym)
  (cond ((string= sym "*") "R")
        ((some #'lower-case-p sym) (string-upcase sym))
        (t sym)))

(defun %peek (s)
  (and (< (smiles-state-pos s) (length (smiles-state-string s)))
       (char (smiles-state-string s) (smiles-state-pos s))))

(defun %next (s) (prog1 (%peek s) (incf (smiles-state-pos s))))

(defun %skipws (s)
  (loop while (and (%peek s) (member (%peek s) '(#\Space #\Tab #\Newline #\Return)))
        do (incf (smiles-state-pos s))))

(defun %digit-p (ch) (and ch (char<= #\0 ch #\9)))

(defun %add-atom (s element-id &key charge isotope aromatic)
  (incf (smiles-state-counter s))
  (let* ((n (smiles-state-counter s))
         (aname (format nil "~A~A" (string-upcase element-id) n))
         (mol (smiles-state-molecule s)))
    (add-atom mol element-id aname)
    (let ((a (get-atom mol aname)))
      (when charge (setf (charge a) charge))
      (when isotope (setf (isotope a) isotope))
      (when aromatic (setf (gethash a (smiles-state-aromatic s)) t))
      a)))

(defun %bond-between (mol a n)
  "The bond object between atoms A and N."
  (find n (find-bonds-containing mol a)
        :test (lambda (x b)
                (or (eq (slot-value b 'epigraph:node1) x)
                    (eq (slot-value b 'epigraph:node2) x)))))

(defun %default-bond-kind (s a1 a2 explicit)
  (or explicit
      (if (and (gethash a1 (smiles-state-aromatic s))
               (gethash a2 (smiles-state-aromatic s)))
          :aromatic :single)))

(defun %kind-order (kind)
  (ecase kind ((:single) 1) ((:double) 2) ((:triple) 3) ((:aromatic) 1.5)))

(defun %upgrade-bond-order (order new-order)
  "Ring-closure bonds take the stronger of the two specifications."
  (if (and (= order 1.5) (= new-order 1.5)) 1.5 (max order new-order)))

(defun %add-bond-between (s a1 a2 kind)
  (add-bond (smiles-state-molecule s)
            (atom-name a1) (atom-name a2)
            :type kind :order (%kind-order kind)))

(defun %add-bond-between-with-order (s a1 a2 order)
  (add-bond (smiles-state-molecule s)
            (atom-name a1) (atom-name a2)
            :type (cond ((= order 1.5) :aromatic)
                        ((= order 2) :double)
                        ((= order 3) :triple)
                        (t :single))
            :order order))

;;; --------------------------------------------------------------------
;;; the grammar

(defun parse-smiles-string (string &key name (add-implicit-hydrogens t))
  "Parse a SMILES string into a CHEMICL:MOLECULE. With
ADD-IMPLICIT-HYDROGENS (the default, matching upstream), the hydrogens
implied by normal valences are added as real atoms, so
MOLECULAR-FORMULA counts them."
  (let* ((mol (make-molecule :name (or name "smiles")))
         (s (make-smiles-state :string string :molecule mol)))
    (%parse-chain s nil nil)
    (when (< (smiles-state-pos s) (length string))
      (error "SMILES parse stopped at position ~D (~S)"
             (smiles-state-pos s) (subseq string (smiles-state-pos s))))
    (when add-implicit-hydrogens (%complete-hydrogens s))
    mol))

(defun %close-or-open-ring (s a num bond)
  (let ((open (gethash num (smiles-state-rings s))))
    (if open
        (let ((order (%upgrade-bond-order
                      (%kind-order (second open))
                      (%kind-order (%default-bond-kind s a (first open) bond)))))
          (%add-bond-between-with-order s (first open) a order)
          (remhash num (smiles-state-rings s)))
        (setf (gethash num (smiles-state-rings s))
              (list a (%default-bond-kind s a nil bond))))))

(defun %parse-bond-symbol (s)
  (case (%peek s)
    ((#\-) (%next s) :single)
    ((#\=) (%next s) :double)
    ((#\#) (%next s) :triple)
    ((#\:) (%next s) :aromatic)
    ;; stereo bond direction is accepted and dropped
    ((#\/) (%next s) :single)
    ((#\\) (%next s) :single)
    (t nil)))

(defun %ring-number (s)
  (let ((ch (%next s)))
    (cond
      ((digit-char-p ch) (digit-char-p ch))
      ((char= ch #\%)
       (let ((d1 (%next s)) (d2 (%next s)))
         (parse-integer (coerce (list d1 d2) 'string))))
      (t (error "bad ring closure")))))

(defun %parse-atom (s)
  (let ((ch (%peek s)))
    (cond
      ((null ch) nil)
      ((char= ch #\[) (%parse-bracket-atom s))
      ((alpha-char-p ch) (%parse-organic-atom s))
      (t (error "unexpected character ~S at position ~D" ch (smiles-state-pos s))))))

(defun %parse-organic-atom (s)
  (let* ((ch (%peek s))
         (str (smiles-state-string s))
         (pos (smiles-state-pos s))
         (two (and (< (+ pos 1) (length str))
                   (subseq str pos (+ pos 2)))))
    (cond
      ((and two (member two '("Cl" "Br") :test #'string=))
       (incf (smiles-state-pos s) 2)
       (%add-atom s two))
      ((and two (member two '("se" "as") :test #'string=))
       (incf (smiles-state-pos s) 2)
       (%add-atom s (%smiles-element-id two) :aromatic t))
      (t (%next s)
         (%add-atom s (%smiles-element-id (string ch))
                    :aromatic (lower-case-p ch))))))

(defun %parse-bracket-atom (s)
  (%next s)                              ; the [
  (let* ((str (smiles-state-string s))
         (end (position #\] str :start (smiles-state-pos s))))
    (unless end (error "unterminated bracket atom"))
    (let* ((body (subseq str (smiles-state-pos s) end))
           (i 0)
           (len (length body))
           isotope sym hcount charge)
      ;; isotope digits
      (let ((ds (loop while (and (< i len) (%digit-p (char body i)))
                      collect (char body i)
                      do (incf i))))
        (when ds (setf isotope (parse-integer (coerce ds 'string)))))
      ;; symbol: longest match that is a real element (CH4's H is a
      ;; hydrogen count, not part of the symbol); aromatic = lowercase
      (cond
        ((and (< i len) (char= (char body i) #\*))
         (setf sym "*") (incf i))
        ((and (< (+ i 1) len)
              (ignore-errors (get-element (subseq body i (+ i 2)))))
         (setf sym (subseq body i (+ i 2))) (incf i 2))
        ((< i len)
         (setf sym (subseq body i (1+ i))) (incf i)))
      ;; chirality @ or @@ — accepted and dropped
      (when (and (< i len) (char= (char body i) #\@))
        (incf i)
        (when (and (< i len) (char= (char body i) #\@)) (incf i)))
      ;; hydrogen count
      (when (and (< i len) (char= (char body i) #\H))
        (setf hcount 1) (incf i)
        (let ((ds (loop while (and (< i len) (%digit-p (char body i)))
                        collect (char body i)
                        do (incf i))))
          (when ds (setf hcount (parse-integer (coerce ds 'string))))))
      ;; charge: +, ++, +n, -, --, -n
      (when (< i len)
        (let ((c (char body i)))
          (cond
            ((char= c #\+)
             (incf i)
             (setf charge
                   (if (and (< i len) (%digit-p (char body i)))
                       (parse-integer (subseq body i (1+ i)))
                       ;; the first + was already consumed above
                       (let ((n 1) (j i))
                         (loop while (and (< j len) (char= (char body j) #\+))
                           do (incf n) (incf j))
                         n))))
            ((char= c #\-)
             (incf i)
             (setf charge
                   (if (and (< i len) (%digit-p (char body i)))
                       (- (parse-integer (subseq body i (1+ i))))
                       ;; the first - was already consumed above
                       (let ((n 1) (j i))
                         (loop while (and (< j len) (char= (char body j) #\-))
                           do (incf n) (incf j))
                         (- n))))))))
      ;; atom class :n — accepted and dropped
      (setf (smiles-state-pos s) (1+ end))
      (let ((a (%add-atom s (%smiles-element-id sym)
                          :charge charge :isotope isotope
                          :aromatic (and (plusp (length sym))
                                         (some #'lower-case-p sym)))))
        (setf (gethash a (smiles-state-bracket-h s)) hcount)
        a))))

(defun %parse-chain (s prev bond)
  "chain := term* — each term is a branch, a dot, a ring closure, or an
optional bond symbol followed by a ring closure, a branch or an atom."
  (loop
    (%skipws s)
    (let ((ch (%peek s)))
      (cond
        ((null ch) (return))
        ((char= ch #\()
         (%next s)
         (%parse-chain s prev bond)
         (let ((close (%peek s)))
           (when (and close (char= close #\))) (%next s))))
        ((char= ch #\)) (return))
        ((char= ch #\.)
         (%next s)
         (setf prev nil bond nil))
        ((or (%digit-p ch) (char= ch #\%))
         (let ((num (%ring-number s))
               (a (or prev (error "ring closure with no previous atom"))))
           (%close-or-open-ring s a num bond)
           (setf bond nil)))
        (t
         (let ((sym (%parse-bond-symbol s)))
           (when sym (setf bond sym)))
         (let ((ch2 (%peek s)))
           (cond
             ((and ch2 (or (%digit-p ch2) (char= ch2 #\%)))
              (let ((num (%ring-number s))
                    (a (or prev (error "ring closure with no previous atom"))))
                (%close-or-open-ring s a num bond)
                (setf bond nil)))
             ((and ch2 (char= ch2 #\())
              (%next s)
              (%parse-chain s prev bond)
              (let ((close (%peek s)))
                (when (and close (char= close #\))) (%next s))))
             (t
              (let ((a (%parse-atom s)))
                (unless a
                  (error "expected an atom at position ~D" (smiles-state-pos s)))
                (when prev
                  (%add-bond-between s prev a (%default-bond-kind s prev a bond)))
                (setf prev a bond nil))))))))))

;;; --------------------------------------------------------------------
;;; implicit hydrogens

(defun %normal-valence (element-id)
  (or (second (assoc element-id *smiles-organic* :test #'string=))
      (let ((el (ignore-errors (get-element element-id))))
        (and el (first (get-normal-valence el))))))

(defun %complete-hydrogens (s)
  (let ((mol (smiles-state-molecule s)))
    (dolist (a (graph:map-nodes->list #'identity mol))
      (let* ((el (and (slot-boundp a 'element) (element a)))
             (el-id (and el (id el))))
        (unless (or (null el) (string= el-id "H"))
          (let* ((used (loop for b in (find-bonds-containing mol a)
                             sum (or (slot-value b 'order) 1)))
                 (bracket-h (gethash a (smiles-state-bracket-h s)))
                 (valence (%normal-valence el-id))
                 (want (cond
                         (bracket-h bracket-h)
                         (valence (max 0 (floor (- (+ valence (charge a)) used))))
                         (t 0))))
            (dotimes (i want)
              (let ((hname (format nil "H~A-~D" (atom-name a) i)))
                (add-atom mol "H" hname)
                (add-bond mol (atom-name a) hname :type :single :order 1)))))))))

;;; --------------------------------------------------------------------
;;; Port fix: upstream COUNT-ELEMENTS/COUNT-ELEMENT walk the graph with a
;;; DFS from the first node, so disconnected fragments (SMILES dots) are
;;; invisible to MOLECULAR-FORMULA. Count over every atom instead.

(defun count-elements (molecule)
  (let ((element-count-hash (make-hash-table)))
    (graph:map-nodes (lambda (atom)
                       (setf (gethash (element atom) element-count-hash)
                             (1+ (or (gethash (element atom) element-count-hash) 0))))
                     molecule)
    (let (l)
      (maphash (lambda (k v) (push (cons k v) l)) element-count-hash)
      (sort l #'string< :key (lambda (x) (id (car x)))))))

(defun count-element (molecule element-id)
  (let ((element-count 0)
        (element (get-element element-id)))
    (graph:map-nodes (lambda (atom)
                       (when (eq (element atom) element) (incf element-count)))
                     molecule)
    element-count))

;;; --------------------------------------------------------------------
;;; writing (non-canonical: DFS from the first atom in insertion order,
;;; ring digits paired at both ends, hydrogens implicit)

(defun write-smiles-string (molecule)
  "Write MOLECULE as a SMILES string (non-canonical: atoms in insertion
order; branches and ring closures follow a DFS from the first atom).
Hydrogens are implicit (not written)."
  (with-output-to-string (stream)
    (%write-smiles molecule stream)))

(defun write-smiles-string-to-stream (molecule stream)
  (%write-smiles molecule stream))

(defun %smiles-sym (a)
  (let ((el (and (slot-boundp a 'element) (element a))))
    (cond ((null el) "*")
          ((string= (id el) "R") "*")
          (t (id el)))))

(defun other-end (b a)
  (if (eq (slot-value b 'epigraph:node1) a)
      (slot-value b 'epigraph:node2)
      (slot-value b 'epigraph:node1)))

(defun %heavy-neighbors (mol a)
  (remove-if (lambda (n) (string= (%smiles-sym n) "H"))
             (mapcar (lambda (b) (other-end b a))
                     (find-bonds-containing mol a))))

(defun bond-chars (b)
  (case (or (slot-value b 'order) 1)
    (2 "=") (3 "#") (1.5 "") (t "")))

(defun %aromatic-atom-p (mol a)
  "An atom writes lowercase when it sits on at least one aromatic bond
and has no double/triple bonds (an n with a single substituent is still
aromatic; a carbonyl c is not)."
  (let ((bonds (remove-if (lambda (b) (string= (%smiles-sym (other-end b a)) "H"))
                          (find-bonds-containing mol a))))
    (and (some (lambda (b) (= (or (slot-value b 'order) 1) 1.5)) bonds)
         (every (lambda (b) (<= (or (slot-value b 'order) 1) 1.5)) bonds))))

(defun %charge-suffix (n)
  (cond ((= n 1) "+") ((= n -1) "-")
        ((> n 0) (format nil "+~D" n))
        (t (format nil "-~D" (- n)))))

(defun %atom-string (mol a)
  "The SMILES token for A: bracketed when it carries a charge, an
isotope, an explicit hydrogen count, or a multi-letter symbol;
lowercase when aromatic."
  (let* ((sym (%smiles-sym a))
         (aromatic (%aromatic-atom-p mol a))
         (hs (count-if (lambda (n) (string= (%smiles-sym n) "H"))
                       (mapcar (lambda (b) (other-end b a))
                               (find-bonds-containing mol a))))
         (needs-bracket (or (/= (charge a) 0)
                            (and (slot-boundp a 'isotope) (isotope a))
                            (> hs 0)
                            (> (length sym) 1))))
    (cond
      (needs-bracket
       (format nil "[~A~A~A~A]"
               (if (and (slot-boundp a 'isotope) (isotope a))
                   (format nil "~D" (isotope a)) "")
               (if aromatic (string-downcase sym) sym)
               (if (> hs 0) (format nil "H~A" (if (> hs 1) hs "")) "")
               (if (/= (charge a) 0) (%charge-suffix (charge a)) "")))
      (aromatic (string-downcase sym))
      (t sym))))

(defun %write-smiles (mol stream)
  ;; phase 1: DFS over the heavy-atom graph — tree bonds become the
  ;; chain, every other bond becomes a ring closure with a digit printed
  ;; at BOTH of its atoms
  (let ((visited (make-hash-table :test 'eq))
        (tree-bonds (make-hash-table :test 'eq))
        (ring-digit (make-hash-table :test 'eq))   ; bond → digit string
        (atom-rings (make-hash-table :test 'eq))   ; atom → its ring bonds
        (ring-counter 0))
    (labels ((dfs (a)
               (setf (gethash a visited) t)
               (dolist (n (%heavy-neighbors mol a))
                 (let ((b (%bond-between mol a n)))
                   (cond
                     ((gethash n visited)
                      (unless (or (gethash b tree-bonds) (gethash b ring-digit))
                        (incf ring-counter)
                        (setf (gethash b ring-digit)
                              (if (> ring-counter 9)
                                  (format nil "%~2,'0D" ring-counter)
                                  (format nil "~D" ring-counter)))
                        (push b (gethash a atom-rings))
                        (push b (gethash n atom-rings))))
                     (t
                      (setf (gethash b tree-bonds) t)
                      (dfs n)))))))
      (dolist (a (graph:map-nodes->list #'identity mol))
        (unless (or (gethash a visited) (string= (%smiles-sym a) "H"))
          (dfs a))))
    ;; phase 2: emit in the same DFS order
    (let ((written (make-hash-table :test 'eq))
          (anything nil))
      (labels ((visit (a)
                 (setf (gethash a written) t)
                 ;; ring digits: the closing end also prints the bond
                 (dolist (b (reverse (gethash a atom-rings)))
                   (when (gethash (other-end b a) written)
                     (princ (bond-chars b) stream))
                   (princ (gethash b ring-digit) stream))
                 ;; tree children: all but the last are branches FIRST
                 ;; (SMILES branches attach to the atom they follow),
                 ;; the last child continues the chain
                 (let ((children (remove-if (lambda (n) (gethash n written))
                                            (%heavy-neighbors mol a))))
                   (when children
                     (let ((branches (butlast children))
                           (chain (car (last children))))
                       (dolist (n branches)
                         (let ((b (%bond-between mol a n)))
                           (when (gethash b tree-bonds)
                             (princ "(" stream)
                             (princ (bond-chars b) stream)
                             (princ (%atom-string mol n) stream)
                             (visit n)
                             (princ ")" stream))))
                       (let ((b (%bond-between mol a chain)))
                         (when (gethash b tree-bonds)
                           (princ (bond-chars b) stream)
                           (princ (%atom-string mol chain) stream)
                           (visit chain))))))))
        (dolist (a (graph:map-nodes->list #'identity mol))
          (unless (or (gethash a written) (string= (%smiles-sym a) "H"))
            (when anything (princ "." stream))
            (setf anything t)
            (princ (%atom-string mol a) stream)
            (visit a)))))))
