;;;; init.lisp — entry file, loaded LAST by the project loader.
;;;; The loader already brings the system up (asd component order); this
;;;; file just proves it with a hand-built molecule.

(in-package #:cl-user)

;;; caffeine (1,3,7-trimethylxanthine), C8H10N4O2, by hand —
;;; SMILES parsing is not part of this port (see PORT-NOTES.md)
(defparameter *caffeine*
  (let ((mol (chemicl:make-molecule :name "caffeine")))
    ;; xanthine skeleton: six-ring N1-C2-N3-C4-C5-C6, five-ring C4-C5-N7-C8-N9
    (dolist (pair '((6 "C2") (7 "N1") (7 "N3") (6 "C4") (6 "C5") (6 "C6")
                   (7 "N7") (6 "C8") (7 "N9") (8 "O1") (8 "O2")
                   ;; three methyl carbons + ten hydrogens
                   (6 "M1") (6 "M2") (6 "M3")))
      (apply #'chemicl:add-atom mol pair))
    (loop for i from 1 to 10 do (chemicl:add-atom mol 1 (format nil "H~A" i)))
    (dolist (pair '(("N1" "C2") ("C2" "N3") ("N3" "C4") ("C4" "C5")
                   ("C5" "C6") ("C6" "N1")           ; six-ring
                   ("C4" "N9") ("N9" "C8") ("C8" "N7") ("N7" "C5") ; five-ring
                   ("C2" "O1") ("C6" "O2")           ; carbonyls
                   ("N1" "M1") ("N3" "M2") ("N7" "M3") ; N-methyls
                   ("M1" "H1") ("M1" "H2") ("M1" "H3")
                   ("M2" "H4") ("M2" "H5") ("M2" "H6")
                   ("M3" "H7") ("M3" "H8") ("M3" "H9")
                   ("C8" "H10")))
      (apply #'chemicl:add-bond mol pair))
    mol))
