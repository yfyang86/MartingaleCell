;;;; init.lisp — entry file, loaded LAST by the project loader.
;;;; The loader already brings the system up (asd component order); this
;;;; file just proves it.

(in-package #:cl-user)

;;; caffeine, straight from its canonical SMILES
(defparameter *caffeine*
  (chemicl:parse-smiles-string "Cn1cnc2c1c(=O)n(C)c(=O)n2C" :name "caffeine"))

;;; and a few friends everyone knows
(defparameter *aspirin*
  (chemicl:parse-smiles-string "CC(=O)Oc1ccccc1C(=O)O" :name "aspirin"))
(defparameter *benzene*
  (chemicl:parse-smiles-string "c1ccccc1" :name "benzene"))
