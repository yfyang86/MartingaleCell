# chemicl — MartingaleCell browser port

Port of Cyrus Harmon's [chemicl](https://github.com/slyrus/chemicl)
(BSD, © 2008–2014; see COPYRIGHT-chemicl), bundled as a sample project
the same way cl-plot is. What changed for the browser runtimes:

- **Element/isotope data**: the original parses `data/elementdata.xml`
  and `data/isotopes.xml` with cxml + cxml-stp + xpath. Those files were
  converted once into `elements-data.lisp` (sexp), and
  `chemicl-elements.lisp` now loads that — no XML stack. Data itself is
  untouched (OpenBabel / Webelements / IUPAC, via chemicl's files).
- **epigraph** (slyrus/epigraph, BSD) is vendored whole (package,
  utilities, epigraph, simple-edge-list-graph) with a minimal
  ALEXANDRIA package providing the two functions epigraph uses
  (hash-table-keys, copy-hash-table).
- **SMILES parsing is not ported**: smiles.lisp/smiles2/smiles3 depend
  on parser-combinators and fset, which are not vendored. Build
  molecules with add-atom/add-bond (see init.lisp's caffeine).
- Everything else (molecules, bonds, rings, primes, canonicalization,
  molecular-formula, mass, exact-mass) is upstream code, unmodified
  apart from the element-data loading.

Upstream files → port files (flat, for the project loader):
package.lisp → chemicl-package.lisp, util.lisp → chemicl-util.lisp,
elements.lisp → chemicl-elements.lisp, chemicl.lisp → chemicl.lisp,
rings.lisp → chemicl-rings.lisp, primes.lisp → chemicl-primes.lisp,
canonicalize.lisp → chemicl-canonicalize.lisp.
