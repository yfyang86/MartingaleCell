# chemicl — MartingaleCell browser port

Port of Cyrus Harmon's [chemicl](https://github.com/slyrus/chemicl)
(BSD, © 2008–2014; see COPYRIGHT-chemicl), bundled as a sample project
the same way cl-plot is. What changed for the browser runtimes:

- **Element/isotope data**: the original parses `data/elementdata.xml`
  and `data/isotopes.xml` with cxml + cxml-stp + xpath. Those files were
  converted once into `elements-data.lisp` (sexp), and
  `chemicl-elements.lisp` now loads that — no XML stack. Data itself is
  untouched (OpenBabel / Webelements / IUPAC, via chemicl's files).
- **epigraph** (slyrus/epigraph, BSD) is vendored whole (package,
  utilities, epigraph, simple-edge-list-graph) with a minimal
  ALEXANDRIA package providing the two functions epigraph uses
  (hash-table-keys, copy-hash-table).
- **SMILES is a fresh implementation** (`chemicl-smiles.lisp`): the
  upstream parser (smiles.lisp/smiles2/smiles3) is built on
  parser-combinators + fset, which are not vendored, so
  `parse-smiles-string` / `write-smiles-string` are re-implemented as a
  plain recursive-descent parser/writer over the same API. Supported:
  organic + bracket atoms, bonds (- = # : and stereo //\ accepted,
  direction dropped), branches (also after a bond symbol), ring
  closures (digits, %nn, reusable after closing), dots (fragments),
  implicit-hydrogen completion. Not carried: stereochemistry and atom
  classes (a 2-D atom/bond graph cannot hold them). The writer is
  non-canonical (insertion-order DFS) but round-trips: write → parse
  reproduces the formula and mass exactly. Verified against RDKit
  2026.03 over an 18-SMILES battery (17 formula+mass matches; the one
  difference is [13CH4], where RDKit's MolWt uses the 13C isotope mass
  while chemicl's MASS is the average element mass by design —
  EXACT-MASS covers isotopes).
- Everything else (molecules, bonds, rings, primes, canonicalization,
  molecular-formula, mass, exact-mass) is upstream code, unmodified
  apart from the element-data loading.

Upstream files → port files (flat, for the project loader):
package.lisp → chemicl-package.lisp, util.lisp → chemicl-util.lisp,
elements.lisp → chemicl-elements.lisp, chemicl.lisp → chemicl.lisp,
rings.lisp → chemicl-rings.lisp, primes.lisp → chemicl-primes.lisp,
canonicalize.lisp → chemicl-canonicalize.lisp; chemicl-smiles.lisp is
new (see above).

Also carried in the port:
- epigraph's node-position/node-find/node-remove forwarded both :test
  and :test-not to sequence functions, which ANSI forbids — fixed.
- upstream read-isotope-data destructured `(id isotopes)` positionally,
  so only the first isotope of each element was ever read — fixed.
- upstream count-elements/count-element DFS-walk from the first node,
  so disconnected fragments were invisible to molecular-formula —
  the port counts every atom.
